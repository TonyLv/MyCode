package com.fmr.ma.autoreasoning.pipeline

// Here,  T  represents the type of input data, and  U  represents
// the type of output data. This allows for flexibility in what
// each stage can accept and produce.
trait AutoReasoningPipeline[T, U] {
  def getAutoReasoningPipelineStageName: String

  def process(inputData: T): U
}
