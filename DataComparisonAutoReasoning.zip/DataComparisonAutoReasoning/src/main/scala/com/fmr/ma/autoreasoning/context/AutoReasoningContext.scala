package com.fmr.ma.autoreasoning.context

import com.fmr.ma.autoreasoning.datareader.DataReader
import com.fmr.ma.autoreasoning.input.ProdParallelInput
import com.fmr.ma.autoreasoning.process.AutoReasoning

// AutoReasoningContext is used to define immutable global run parameters.
case class AutoReasoningContext(
    // which data entity need to do auto reasoning
    entity: String,
    // configuration file path
    confUri: String,
    // input data from product parallel
    prodParallelInput: ProdParallelInput,
    // data reader inside the auto reason
    dataReaderMap: Map[String, DataReader],
    // auto reasoning inside the auto reasoning
    autoReasoningMap: Map[String, AutoReasoning]
)
