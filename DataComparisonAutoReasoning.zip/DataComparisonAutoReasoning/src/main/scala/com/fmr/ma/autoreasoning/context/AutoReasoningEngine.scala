package com.fmr.ma.autoreasoning.context

import cats.data.OptionT.some
import com.fmr.ma.autoreasoning.config.{
  AutoReasoningConfig,
  AutoReasoningConfigParsor
}
import com.fmr.ma.autoreasoning.context.AutoReasoningErrors.ConfigError
import com.fmr.ma.autoreasoning.datareader._
import com.fmr.ma.autoreasoning.process.AutoReasoning

import scala.tools.nsc.io.File

object AutoReasoningEngine {

  def setUpAutoReasoningContext(
      configUrl: Option[String]
  ): Either[List[AutoReasoningErrors], AutoReasoningContext] = {

    val configFileInputStream = File(configUrl.get).inputStream()
    AutoReasoningConfigParsor.parseConfFile(configFileInputStream) match {
      case Left(error) =>
        Left(
          ConfigError(
            "Config file",
            s"Parsing config file error:---> ${error}"
          ) :: Nil
        )
      case Right(conf) => Right(parseConfigurationFile(configUrl.get, conf))
    }
  }

  def parseConfigurationFile(
      confUri: String,
      autoReasoningConfig: AutoReasoningConfig
  ): AutoReasoningContext = {
    val entity = autoReasoningConfig.entity

    // covert List[DataReader] into Map[String, DataReader]
    val dataReaderMap: Map[String, DataReader] =
      autoReasoningConfig.dataReader.map(dr => (dr.getDataSourceKey, dr)).toMap

    // product parallel input
    val prodParallelInput = autoReasoningConfig.prodParallelInput

    // covert List[AutoReasoning] into Map[String, AutoReasoning]

    val autoReasoningMap: Map[String, AutoReasoning] =
      autoReasoningConfig.autoReasoning.map(ar => (ar.column, ar)).toMap

    AutoReasoningContext(
      entity,
      confUri,
      prodParallelInput,
      dataReaderMap,
      autoReasoningMap
    )
  }
}
