package com.fmr.ma.autoreasoning.datareader

case class OracleDBDataSource(
    dataSourceKey: String,
    dataReaderType: String = "Oracle",
    dbUrl: String,
    secertPath: String
) extends DataReader {
  override def getDataReaderType: String = dataReaderType
}
