package com.fmr.ma.autoreasoning.datareader

import org.apache.spark.sql.{DataFrame, SparkSession}

import java.util.Properties

case class OracleDBDataSource(
    dataSourceKey: String,
    dataReaderType: String = "Oracle",
    dbUrl: String,
    secertPath: String
) extends DataReader {
  override def getDataReaderType: String = dataReaderType
  override def getDataSourceKey: String  = dataSourceKey

  private def getConnectionProperties: Properties = {
    val connectionProperties = new Properties()
    connectionProperties.put("user", "postgres")
    connectionProperties.put("password", "postgres")
    connectionProperties
  }

  def readDataFromQuery(
      spark: SparkSession,
      query: String,
      condition: String
  ): DataFrame = {
    Class.forName("org.postgresql.Driver")

    val finalQuery =
      if (condition.nonEmpty) s"$query WHERE $condition" else query
    spark.read.jdbc(
      dbUrl,
      s"($finalQuery) as queryResult",
      getConnectionProperties
    )
  }
}
