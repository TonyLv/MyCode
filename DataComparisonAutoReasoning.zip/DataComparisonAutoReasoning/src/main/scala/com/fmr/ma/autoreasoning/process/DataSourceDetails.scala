package com.fmr.ma.autoreasoning.process

case class DataSourceDetails(
    dataSourceKey: String,
    query: String,
    sparkViewName: String
)
object DataSourceDetails {}
