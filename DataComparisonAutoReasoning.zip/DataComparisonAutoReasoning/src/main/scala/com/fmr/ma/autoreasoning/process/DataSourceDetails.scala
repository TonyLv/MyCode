package com.fmr.ma.autoreasoning.process

import com.fmr.ma.autoreasoning.context.AutoReasoningErrors.CommonError
import com.fmr.ma.autoreasoning.context.{
  AutoReasoningContext,
  AutoReasoningErrors
}
import com.fmr.ma.autoreasoning.datareader._
import org.apache.spark.sql.{DataFrame, SparkSession}

case class DataSourceDetails(
    dataSourceKey: String,
    query: String,
    sparkViewName: String
) {
  // get the data from query, covert the result into spark sql view
  def getDataIntoView()(
      spark: SparkSession,
      autoReasoningContext: AutoReasoningContext
  ): Either[AutoReasoningErrors, DataFrame] = {

    autoReasoningContext.dataReaderMap.get(dataSourceKey) match {
      case Some(dataReader) => {
        dataReader.getDataReaderType match {
          case "Postgres" => {
            val postgresDR = dataReader.asInstanceOf[PostgresDataSource]
            Right(postgresDR.readDataFromQuery(spark, query, ""))
          }
          case "Oracle" => {
            val oracleDR = dataReader.asInstanceOf[OracleDBDataSource]
            Right(oracleDR.readDataFromQuery(spark, query, ""))
          }
        }
      }
      case None =>
        Left(
          CommonError(
            "DataSourceDetails--getDataIntoView",
            s"No data reader found for key $dataSourceKey"
          )
        )
    }
  }
}
object DataSourceDetails {}
