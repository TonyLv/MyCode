package com.fmr.ma.autoreasoning.datareader

case class PostgresDataSource(
    dataSourceKey: String,
    dataReaderType: String = "Postgres",
    dbUrl: String,
    secertPath: String
) extends DataReader {
  override def getDataReaderType: String = dataReaderType
}
