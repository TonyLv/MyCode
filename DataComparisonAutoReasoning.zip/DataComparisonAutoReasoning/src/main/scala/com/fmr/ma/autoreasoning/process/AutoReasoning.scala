package com.fmr.ma.autoreasoning.process

case class AutoReasoning(
    column: String,
    autoReasoningSequence: List[AutoReasoningSequence],
    resultFile: String
)

object AutoReasoning {}
