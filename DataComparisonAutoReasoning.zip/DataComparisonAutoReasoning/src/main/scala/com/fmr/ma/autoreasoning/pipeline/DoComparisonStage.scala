package com.fmr.ma.autoreasoning.pipeline

import com.fmr.ma.autoreasoning.context.AutoReasoningErrors
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
// Input: leftDataFrame, rightDataFrame to do comparison
// Output: DataFrame includes the comparison result
case class DoComparisonStage(keyColumns: String, compareColumns: String)(
    implicit spark: SparkSession
) extends AutoReasoningPipeline[(DataFrame, DataFrame), DataFrame] {

  override def getAutoReasoningPipelineStageName: String = "DoComparisonStage"

  override def process(inputDataTuple: (DataFrame, DataFrame)): DataFrame = {

    import spark.implicits._

    val sourceDF = inputDataTuple._1
    val targetDF = inputDataTuple._2

    // Splitting the strings into arrays
    val keyColumnsArray     = keyColumns.split(",").map(_.trim)
    val compareColumnsArray = compareColumns.split(",").map(_.trim)

    // Constructing join condition dynamically
    val joinCondition = keyColumnsArray
      .map(colName => sourceDF(colName) === targetDF(colName))
      .reduce(_ && _)

    // Dynamic filter condition for differing comparison columns
    val compareCondition = compareColumnsArray
      .map(colName => $"source.$colName" =!= $"target.$colName")
      .reduce(_ || _)

    val comparisonColumns =
      Array(monotonically_increasing_id().alias("id")) ++
        keyColumnsArray.map(colName =>
          $"source.$colName".alias(s"${colName}_source")
        ) ++
        keyColumnsArray.map(colName =>
          $"target.$colName".alias(s"${colName}_target")
        ) ++
        compareColumnsArray.map(colName =>
          $"source.$colName".alias(s"${colName}_source")
        ) ++
        compareColumnsArray.map(colName =>
          $"target.$colName".alias(s"${colName}_target")
        )

    val diffDF = sourceDF
      .as("source")
      .join(
        targetDF.as("target"),
        joinCondition
      ) // Perform an inner join on key columns
      .filter(
        compareCondition
      )
      .select(
        comparisonColumns.toSeq: _*
      )

    // return the resulting DataFrame
    diffDF
  }
}
