package com.fmr.ma.autoreasoning.process

case class AutoReasoningSequence(
    leftDataSource: DataSourceDetails,
    rightDataSource: DataSourceDetails
)

object AutoReasoningSequence {}
