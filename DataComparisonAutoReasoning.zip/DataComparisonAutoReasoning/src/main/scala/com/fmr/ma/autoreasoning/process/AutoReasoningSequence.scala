package com.fmr.ma.autoreasoning.process

case class AutoReasoningSequence(
    leftDataSource: DataSourceDetails,
    rightDataSource: DataSourceDetails,
    keyColumns: String,
    compareColumns: String
)

object AutoReasoningSequence {}
