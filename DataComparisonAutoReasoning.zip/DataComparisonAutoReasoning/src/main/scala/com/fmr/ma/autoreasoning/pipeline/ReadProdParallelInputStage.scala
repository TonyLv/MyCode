package com.fmr.ma.autoreasoning.pipeline

import com.fmr.ma.autoreasoning.context.{
  AutoReasoningContext,
  AutoReasoningErrors
}
import com.fmr.ma.autoreasoning.datareader.S3FileDataSource
import org.apache.spark.sql.{DataFrame, SparkSession}

case class ReadProdParallelInputStage()(implicit
    spark: SparkSession,
    autoReasoningContext: AutoReasoningContext
) extends AutoReasoningPipeline[
      String,
      Either[AutoReasoningErrors, DataFrame]
    ] {
  override def getAutoReasoningPipelineStageName: String =
    "ProdParallelInputStage"

  // Step 1 : get the dataframe from data source, like from S3FileDataSource
  private def getInputFileDataFrom(): Either[AutoReasoningErrors, DataFrame] = {

    val filePathKey = autoReasoningContext.prodParallelInput.fileSource

    val s3FileDataSource =
      autoReasoningContext
        .dataReaderMap(filePathKey)
        .asInstanceOf[S3FileDataSource]

    s3FileDataSource.getDataFrameFromFile(spark)

  }
  // Step 2 : get the dataframe after filter using ProdParallelInput
  private def getInputDataAfterFilter(
      prodParallelInputData: DataFrame
  ): Either[AutoReasoningErrors, DataFrame] = {
    val prodParallelInput = autoReasoningContext.prodParallelInput
    prodParallelInput.getInputDataAfterFilter(prodParallelInputData)
  }

  // Step 3: get the data from the product parallel
  override def process(
      inputData: String
  ): Either[AutoReasoningErrors, DataFrame] = {
    for {

      prodParallelInputData <- getInputFileDataFrom()
      prodParallelInputDataAfterFilter <- getInputDataAfterFilter(
        prodParallelInputData
      )
    } yield {
      prodParallelInputDataAfterFilter
    }
  }
}
