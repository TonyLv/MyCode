package com.fmr.ma.autoreasoning.config

import com.fmr.ma.autoreasoning.datareader._
import com.fmr.ma.autoreasoning.input.ProdParallelInput
import com.fmr.ma.autoreasoning.process.{
  AutoReasoning,
  AutoReasoningSequence,
  DataSourceDetails
}
import io.circe.{Decoder, DecodingFailure}
import io.circe.generic.semiauto.deriveDecoder

// Parsing the configuration file
case class AutoReasoningConfig(
    entity: String,
    dataReader: List[DataReader],
    prodParallelInput: ProdParallelInput,
    autoReasoning: List[AutoReasoning]
) {}

object AutoReasoningConfig {

  // data reader decoder
  implicit val autoReasoningConfigDecoder: Decoder[AutoReasoningConfig] =
    deriveDecoder[AutoReasoningConfig]

  implicit val oracleDBDataSourceDecoder: Decoder[OracleDBDataSource] =
    deriveDecoder[OracleDBDataSource]

  implicit val postgresDataSourceDecoder: Decoder[PostgresDataSource] =
    deriveDecoder[PostgresDataSource]

  implicit val s3FileDataSourceDecoder: Decoder[S3FileDataSource] =
    deriveDecoder[S3FileDataSource]

  implicit val apiDataSourceDecoder: Decoder[APIDataSource] =
    deriveDecoder[APIDataSource]

  implicit val dataReaderDecoder: Decoder[DataReader] = Decoder.instance { c =>
    c.downField("dataReaderType").as[String].flatMap {
      case "Oracle"   => oracleDBDataSourceDecoder.tryDecode(c)
      case "Postgres" => postgresDataSourceDecoder.tryDecode(c)
      case "S3File"   => s3FileDataSourceDecoder.tryDecode(c)
      case "API"      => apiDataSourceDecoder.tryDecode(c)
      case other =>
        Left(DecodingFailure(s"Unknown dataReaderType: $other", c.history))
    }
  }

  // product parallel input
  implicit val prodParallelInput: Decoder[ProdParallelInput] =
    deriveDecoder[ProdParallelInput]

  // auto reason configuration
  implicit val autoReasoning: Decoder[AutoReasoning] =
    deriveDecoder[AutoReasoning]

  implicit val autoReasoningSequence: Decoder[AutoReasoningSequence] =
    deriveDecoder[AutoReasoningSequence]

  implicit val dataSourceDetails: Decoder[DataSourceDetails] =
    deriveDecoder[DataSourceDetails]

}
