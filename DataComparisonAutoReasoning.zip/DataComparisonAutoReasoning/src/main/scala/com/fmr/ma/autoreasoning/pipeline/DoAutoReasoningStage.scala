package com.fmr.ma.autoreasoning.pipeline

import com.fmr.ma.autoreasoning.context.{
  AutoReasoningContext,
  AutoReasoningErrors
}
import com.fmr.ma.autoreasoning.process.DataSourceDetails
import org.apache.spark.sql.{DataFrame, SparkSession}

case class DoAutoReasoningStage()(implicit
    spark: SparkSession,
    autoReasoningContext: AutoReasoningContext
) extends AutoReasoningPipeline[DataFrame, String] {
  override def getAutoReasoningPipelineStageName: String = "AutoReasoningStage"

  // Doing the auto reasoning process and return Map type indicating the difference for each comparable column report
  // Map[comparable column, List[Reasoning report for each steps]]
//  def runAutoReasoningStage()
//      : Either[AutoReasoningErrors, Map[String, List[DataFrame]]] = {

  override def process(
      inputData: DataFrame // from prod comparison input
  ): String = {

    val autoReasoningMap = autoReasoningContext.autoReasoningMap
    autoReasoningMap.foreach { case (comparableColumn, autoReasoning) =>
      // Assuming independence, use parallel collections
      autoReasoning.autoReasoningSequence.par.foreach { autoReasoningStep =>
        processDataSource(
          autoReasoningStep.leftDataSource,
          "left",
          comparableColumn,
          inputData // condition dataframe
        )
        processDataSource(
          autoReasoningStep.rightDataSource,
          "right",
          comparableColumn,
          inputData // condition dataframe
        )
      // Steps 2: Call the Mujeeb comparison function
      }
    }
    ""
  }

  def processDataSource(
      dataSource: DataSourceDetails,
      side: String,
      comparableColumn: String,
      conditionDF: DataFrame = null
  ): Unit = {
    dataSource.getDataIntoView()(spark, autoReasoningContext) match {
      case Left(exception) =>
        logError(s"$side DataFrame---$comparableColumn--error--->", exception)
      case Right(dataFrame) =>
        logDataFrameInfo(
          s"$side DataFrame---$comparableColumn---data--->",
          dataFrame
        )
        // Filter out the conditionDF from dataFrame
        filterOutDataFrame(dataFrame, conditionDF)
    }
  }

  // filter out the data from prod parallel input
  private def filterOutDataFrame(
      mainDf: DataFrame,
      conditionDf: DataFrame
  ): DataFrame = {
    // Step 1: Identify common columns
    val commonColumns = mainDf.columns.intersect(conditionDf.columns)

    // Step 2 & 3: Construct join condition based on common columns
    val joinCondition =
      commonColumns
        .map(colName => mainDf(colName) === conditionDf(colName))
        .reduce(_ && _)

    // Step 4: Perform the semi-join
    val filteredDf = mainDf.join(conditionDf, joinCondition, "semi")

    filteredDf

  }

  def logError(message: String, exception: AutoReasoningErrors): Unit = {
    // Implement logging using a logging framework
    println(s"$message: $exception")
  }

  def logDataFrameInfo(message: String, dataFrame: DataFrame): Unit = {
    // For debugging purposes, consider logging the schema or a row count instead of showing the entire DataFrame
    println(s"$message Schema: ${dataFrame.schema.treeString}")
    dataFrame.show
  }
}
