package com.fmr.ma.autoreasoning.input

import com.fmr.ma.autoreasoning.context.AutoReasoningErrors
import com.fmr.ma.autoreasoning.context.AutoReasoningErrors.CommonError
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col

case class ProdParallelInput(
    fileSource: String,
    fileType: String,
    columns: List[String],
    filter: List[String],
    conditionParamForAutoReasoning: String
) {
  def getInputDataAfterFilter(
      inputProdParallelDF: DataFrame
  ): Either[AutoReasoningErrors, DataFrame] = {
    // Select the columns from the column list
    val selectedColumns = columns.map(col)
    // Apply the filters from the filter list
    val filteredDF =
      filter.foldLeft(inputProdParallelDF)((df, filter) => df.filter(filter))

    filteredDF.select(selectedColumns: _*) match {
      case df: DataFrame => {
        // Parse the input string to get a list of (originalColumnName, newColumnName) tuples
        val reNamings: Array[(String, String)] =
          conditionParamForAutoReasoning.split(",").map { renaming =>
            val parts = renaming.trim.split("=>").map(_.trim)
            (parts(0), parts(1))
          }

        // Apply the renamings to the DataFrame
        val renamedDf = reNamings.foldLeft(df) { (tempDf, renaming) =>
          tempDf.withColumnRenamed(renaming._1, renaming._2)
        }

        // Extract only the new column names for selection
        val newColumnNames = reNamings.map(_._2)

        // Right(df.select(columnNames.map(name => col(name)): _*))
        Right(renamedDf.select(newColumnNames.head, newColumnNames.tail: _*))
      }
      case _ =>
        Left(
          CommonError(
            "ProdParallelInput",
            s"getInputDataAfterFilter has some error!"
          )
        )
    }
  }
}

object ProdParallelInput {}
