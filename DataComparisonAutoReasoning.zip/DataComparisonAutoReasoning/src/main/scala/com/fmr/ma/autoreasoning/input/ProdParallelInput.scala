package com.fmr.ma.autoreasoning.input

case class ProdParallelInput(
    fileSource: String,
    fileType: String,
    columns: List[String],
    filter: List[String],
    outputParam: String
)

object ProdParallelInput {}
