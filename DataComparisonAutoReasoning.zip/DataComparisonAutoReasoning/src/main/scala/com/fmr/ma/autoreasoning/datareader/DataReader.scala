package com.fmr.ma.autoreasoning.datareader

trait DataReader {
  def getDataReaderType: String
}
