package com.fmr.ma.autoreasoning.datareader

trait DataReader extends Serializable {
  def getDataReaderType: String
  def getDataSourceKey: String
}
