package com.fmr.ma.autoreasoning.config

import java.io.InputStream
import scala.io._
import io.circe._
import io.circe.generic.codec.DerivedAsObjectCodec._
import io.circe.parser.decode

import scala.util._

object AutoReasoningConfigParsor {

  def bufferContentAsString(buffer: BufferedSource): String = {
    val contents = buffer.mkString
    buffer.close()
    contents
  }

  def loadFromFile(configFileInputStream: InputStream): String = {

    val config = Source.fromInputStream(configFileInputStream)

    bufferContentAsString(config)
  }

  def parseConfFile(
      confFileInputStream: InputStream
  ): Either[Error, AutoReasoningConfig] = {
    Try {
      loadFromFile(confFileInputStream)
    } match {
      case Success(conf) => parseConfig(conf)
      case Failure(e) =>
        Left(DecodingFailure(e.getMessage, Nil))
    }
  }

  def parseConfig(
      jsonStr: String
  ): Either[io.circe.Error, AutoReasoningConfig] = {
    decode[AutoReasoningConfig](jsonStr)
  }

}
