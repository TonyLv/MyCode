package com.fmr.ma.autoreasoning.context

trait AutoReasoningErrors

object AutoReasoningErrors {

  type Errors = List[ConfigError]

  case class ConfigError(path: String, message: String)
      extends AutoReasoningErrors

  object ConfigError {

    def err(path: String, message: String): Errors =
      ConfigError(path, message) :: Nil

  }

  type StringConfigValue = Either[Errors, String]

  def stringOrDefault(sv: StringConfigValue, default: String): String = {
    sv match {
      case Right(v)  => v
      case Left(err) => default
    }
  }
}
