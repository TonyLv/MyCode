package com.fmr.ma.autoreasoning.context

trait AutoReasoningErrors

object AutoReasoningErrors {

  type Errors       = List[ConfigError]
  type StageErrors  = List[StageError]
  type CommonErrors = List[CommonError]

  case class ConfigError(path: String, message: String)
      extends AutoReasoningErrors

  object ConfigError {

    def err(path: String, message: String): Errors =
      ConfigError(path, message) :: Nil

  }

  case class StageError(
      stage: String,
      message: String
  ) extends AutoReasoningErrors

  object StageError {

    def err(stage: String, message: String): StageErrors =
      StageError(stage, message) :: Nil

  }

  case class CommonError(
      desc: String,
      message: String
  ) extends AutoReasoningErrors

  object CommonError {

    def err(desc: String, message: String): CommonErrors =
      CommonError(desc, message) :: Nil

  }

  type StringConfigValue = Either[Errors, String]

  def stringOrDefault(sv: StringConfigValue, default: String): String = {
    sv match {
      case Right(v)  => v
      case Left(err) => default
    }
  }
}
