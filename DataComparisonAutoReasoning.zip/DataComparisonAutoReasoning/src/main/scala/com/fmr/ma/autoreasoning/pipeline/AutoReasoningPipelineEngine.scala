package com.fmr.ma.autoreasoning.pipeline

import com.fmr.ma.autoreasoning.context.AutoReasoningContext
import org.apache.spark.sql.SparkSession

case class AutoReasoningPipelineEngine()(implicit
    spark: SparkSession,
    autoReasoningContext: AutoReasoningContext
) {
  private val prodParallelInputStage =
    ReadProdParallelInputStage()(spark, autoReasoningContext)
  private val doAutoReasoningStage =
    DoAutoReasoningStage()(spark, autoReasoningContext)

  def runPipeline(inputData: String): Unit = {
    for {
      prodParallelInput <- prodParallelInputStage.process(inputData)
    } yield {
      doAutoReasoningStage.process(prodParallelInput)
    }
  }
}
