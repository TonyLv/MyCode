package com.fmr.ma.autoreasoning.datareader

case class APIDataSource(
    dataSourceKey: String,
    dataReaderType: String = "API",
    urlPath: String
) extends DataReader {
  override def getDataReaderType: String = dataReaderType

  override def getDataSourceKey: String = dataSourceKey
}
