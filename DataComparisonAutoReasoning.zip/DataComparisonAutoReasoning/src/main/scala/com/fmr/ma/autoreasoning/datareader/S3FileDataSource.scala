package com.fmr.ma.autoreasoning.datareader

import com.fmr.ma.autoreasoning.context.AutoReasoningErrors
import com.fmr.ma.autoreasoning.context.AutoReasoningErrors.CommonError
import org.apache.spark.sql.{DataFrame, SparkSession}

case class S3FileDataSource(
    dataSourceKey: String,
    dataReaderType: String = "S3File",
    filePath: String
) extends DataReader {
  override def getDataReaderType: String = dataReaderType
  override def getDataSourceKey: String  = dataSourceKey

  def getDataFrameFromFile(
      spark: SparkSession
  ): Either[AutoReasoningErrors, DataFrame] = {
    try {
      val df = spark.read.format("csv").option("header", "true").load(filePath)
      Right(df)
    } catch {
      case e: Exception =>
        Left(
          CommonError(
            "S3FileDataSource",
            s"Get the file from ${filePath} has some issues which:---> ${e}"
          )
        )
    }
  }
}
