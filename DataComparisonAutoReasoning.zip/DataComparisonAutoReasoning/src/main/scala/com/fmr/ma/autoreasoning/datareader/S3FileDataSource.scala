package com.fmr.ma.autoreasoning.datareader

case class S3FileDataSource(
    dataSourceKey: String,
    dataReaderType: String = "S3File",
    filePath: String
) extends DataReader {
  override def getDataReaderType: String = dataReaderType
}
