package com.fmr.ma.autoreasoning.context

import org.scalatest.funsuite.AnyFunSuite

import scala.tools.nsc.io.File

class AutoReasoningContextUT extends AnyFunSuite {
  test("Create auto reasoning context") {
    AutoReasoningEngine.setUpAutoReasoningContext(
      Some("config/part_1.json")
    ) match {
      case Left(error) => println(s"error------>$error")
      case Right(autoReasoningContext) => {
        autoReasoningContext.autoReasoningMap.foreach(autoReasoning => {
          println(s"autoReasoning------>${autoReasoning._1}")
          println(s"autoReasoning------>${autoReasoning._2}")
        })
      }
    }
  }
}
