package com.fmr.ma.autoreasoning.pipeline

import com.fmr.ma.autoreasoning.SparkUnitTestContext
import com.fmr.ma.autoreasoning.context.{
  AutoReasoningContext,
  AutoReasoningEngine,
  AutoReasoningErrors
}
import org.apache.spark.sql.{DataFrame, SparkSession}

class DoAutoReasoningStageUT extends SparkUnitTestContext {
  test("test to run auto reasoning stage") {

    val spark: SparkSession = ss

    import spark.implicits._

    AutoReasoningEngine
      .setUpAutoReasoningContext(Some("config/part_2.json")) match {
      case Left(error) => {
        println(error.toString)
      }
      case Right(context) => {
        val autoReasoningContext: AutoReasoningContext = context

        val doAutoReasoningStage: DoAutoReasoningStage =
          DoAutoReasoningStage()(spark, autoReasoningContext)

        val inputData     = Seq((1, "foo"), (2, "bar"))
        val df: DataFrame = inputData.toDF("id", "value")

        doAutoReasoningStage.process(df)
      }
    }
  }

}
