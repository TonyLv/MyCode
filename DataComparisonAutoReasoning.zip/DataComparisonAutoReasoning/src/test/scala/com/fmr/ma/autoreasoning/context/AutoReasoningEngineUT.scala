package com.fmr.ma.autoreasoning.context

import com.fmr.ma.autoreasoning.SparkUnitTestContext
import org.apache.spark.sql.SparkSession

class AutoReasoningEngineUT extends SparkUnitTestContext {

  test("Auto Reasoning engine running") {
    val spark: SparkSession = ss

    AutoReasoningEngine.runAutoReasoningPipeline("config/part_2.json", spark)

    succeed
  }

}
