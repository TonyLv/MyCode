package com.fmr.ma.autoreasoning.pipeline

import com.fmr.ma.autoreasoning.SparkUnitTestContext

class DoComparisonStageUT extends SparkUnitTestContext {

  test(
    "do comparison for two dataframes-- keyColumns and compareColumns with only one value"
  ) {

    val spark = ss

    import spark.implicits._
    import org.apache.spark.sql.functions._

    val sourceDF = Seq(
      ("80001", 48.888),
      ("90001", 67.987),
      ("70001", 45.990)
    ).toDF("account_no", "market_value")

    val targetDF = Seq(
      ("80001", 50.888),
      ("90001", 67.987),
      ("70001", 45.987)
    ).toDF("account_no", "market_value")

    val keyColumns     = "account_no"
    val compareColumns = "market_value"

    val diffDF = sourceDF
      .as("source")
      .join(
        targetDF.as("target"),
        keyColumns
      ) // Perform an inner join on account_no
      .filter(
        $"source.market_value" =!= $"target.market_value"
      ) // Filter rows where market_value differs
      .select(
        monotonically_increasing_id().alias(
          "id"
        ), // Generate a unique ID for each row
        $"$keyColumns".alias(s"$keyColumns"),
        $"source.$compareColumns".alias(s"${compareColumns}_source"),
        $"target.$compareColumns".alias(s"${compareColumns}_target")
      )
      .withColumn(
        s"${keyColumns}_source",
        $"$keyColumns"
      ) // Duplicate account_no column for source
      .withColumn(
        s"${keyColumns}_target",
        $"$keyColumns"
      )                     // Duplicate account_no column for target
      .drop(s"$keyColumns") // Remove the original account_no column
      .select(
        "id",
        s"${keyColumns}_source",
        s"${keyColumns}_target",
        s"${compareColumns}_source",
        s"${compareColumns}_target"
      ) // Reorder columns

    // Show the resulting DataFrame
    diffDF.show()
  }

  test(
    "do comparison for two dataframes--  keyColumns and compareColumns with multiple values"
  ) {

    val spark = ss

    import spark.implicits._
    import org.apache.spark.sql.functions._

    // Example DataFrames, adjust columns as needed
    val sourceDF = Seq(
      ("80001", "001", 48.888, 100.1),
      ("90001", "002", 67.987, 200.2),
      ("70001", "003", 45.990, 300.3)
    ).toDF("account_no", "account_no1", "market_value1", "market_value2")

    val targetDF = Seq(
      ("80001", "001", 50.888, 100.1),
      ("90001", "002", 67.987, 205.2),
      ("70001", "003", 45.987, 300.3)
    ).toDF("account_no", "account_no1", "market_value1", "market_value2")

    // Assuming we have these as comma-separated strings
    val keyColumns     = "account_no,account_no1"
    val compareColumns = "market_value1,market_value2"

    // Splitting the strings into arrays
    val keyColumnsArray     = keyColumns.split(",")
    val compareColumnsArray = compareColumns.split(",")

    // Constructing join condition dynamically
    val joinCondition = keyColumnsArray
      .map(colName => sourceDF(colName) === targetDF(colName))
      .reduce(_ && _)

    // Dynamic filter condition for differing comparison columns
    val compareCondition = compareColumnsArray
      .map(colName => $"source.$colName" =!= $"target.$colName")
      .reduce(_ || _)

    val comparisonColumns =
      Array(monotonically_increasing_id().alias("id")) ++
        keyColumnsArray.map(colName =>
          $"source.$colName".alias(s"${colName}_source")
        ) ++
        keyColumnsArray.map(colName =>
          $"target.$colName".alias(s"${colName}_target")
        ) ++
        compareColumnsArray.map(colName =>
          $"source.$colName".alias(s"${colName}_source")
        ) ++
        compareColumnsArray.map(colName =>
          $"target.$colName".alias(s"${colName}_target")
        )

    val diffDF = sourceDF
      .as("source")
      .join(
        targetDF.as("target"),
        joinCondition
      ) // Perform an inner join on key columns
      .filter(
        compareCondition
      )
      .select(
        comparisonColumns.toSeq: _*
      )

    // Show the resulting DataFrame
    diffDF.show()
  }

  test(
    "do comparison for two dataframes-- Call DoComparisonStage method"
  ) {
    val spark = ss

    import spark.implicits._

    val sourceDF = Seq(
      ("80001", 48.888),
      ("90001", 67.987),
      ("70001", 45.990)
    ).toDF("account_no", "market_value")

    val targetDF = Seq(
      ("80001", 50.888),
      ("90001", 67.987),
      ("70001", 45.987)
    ).toDF("account_no", "market_value")

    val keyColumns     = "account_no"
    val compareColumns = "market_value"

    val comparisonStage = DoComparisonStage(keyColumns, compareColumns)(ss)

    comparisonStage.process((sourceDF, targetDF)).show()
  }

}
