package com.fmr.ma.autoreasoning.datareader

import com.fmr.ma.autoreasoning.SparkUnitTestContext

class PostgressDataSourceUT extends SparkUnitTestContext {
  test("read the data from PostgresSQL and turn data into Dataframe") {
    val dataReader = PostgresDataSource(
      "SunTecDB",
      "Postgres",
      "jdbc:postgresql://localhost:5432/postgres",
      ""
    )
    val df = dataReader.readDataFromQuery(
      ss,
      "SELECT account_no, mkt_value FROM public.test_suntec_table",
      "account_no = '1'"
    )
    df.show()
  }
}
