package com.fmr.ma.autoreasoning.datareader

import java.sql.{Connection, DriverManager, ResultSet}

object PostgresConnectorTest {
  val url      = "jdbc:postgresql://localhost:5432/postgres"
  val username = "postgres"
  val password = "postgres"

  def connect(): Unit = {
    var connection: Connection = null
    try {
      // Load the driver
      Class.forName("org.postgresql.Driver")
      // Establish the connection
      connection = DriverManager.getConnection(url, username, password)

      // Example query
      val statement = connection.createStatement()
      val resultSet = statement.executeQuery(
        "SELECT account_no, mkt_value FROM public.test_suntec_table"
      )
      while (resultSet.next()) {
        println(resultSet.getString("account_no"))
      }
    } catch {
      case e: Exception => e.printStackTrace()
    } finally {
      if (connection != null) connection.close()
    }
  }

  def main(args: Array[String]): Unit = {
    PostgresConnectorTest.connect()
  }
}
