package com.fmr.ma.autoreasoning.pipeline

import com.fmr.ma.autoreasoning.SparkUnitTestContext
import com.fmr.ma.autoreasoning.context.AutoReasoningErrors.ConfigError
import com.fmr.ma.autoreasoning.context.{
  AutoReasoningContext,
  AutoReasoningEngine,
  AutoReasoningErrors
}
import org.apache.spark.sql.SparkSession
import org.scalatest.funsuite.AnyFunSuite

class ReadProdParallelInputStageUT extends SparkUnitTestContext {

  test("ReadProdParallelInputStageUT --> read product input file") {

    val spark: SparkSession = ss

    AutoReasoningEngine
      .setUpAutoReasoningContext(Some("config/part_1.json")) match {
      case Left(error) => {
        println(error.toString)
      }
      case Right(context) => {
        val autoReasoningContext: AutoReasoningContext = context

        val readProdParallelInputStage: ReadProdParallelInputStage =
          ReadProdParallelInputStage()(spark, autoReasoningContext)

        readProdParallelInputStage.process("readProdParallelInputStage") match {
          case Left(error) => {
            println(error.toString)
          }
          case Right(df) => {
            df.show()
          }
        }
      }
    }

  }

}
