package com.fmr.ma.autoreasoning.pipeline

import com.fmr.ma.autoreasoning.SparkUnitTestContext
import com.fmr.ma.autoreasoning.context.{
  AutoReasoningContext,
  AutoReasoningEngine
}
import org.apache.spark.sql.{DataFrame, SparkSession}

class AutoReasoningPipelineEngineUT extends SparkUnitTestContext {
  test("run the auto reasoning pipeline") {
    val spark: SparkSession = ss

    import spark.implicits._

    AutoReasoningEngine
      .setUpAutoReasoningContext(Some("config/part_2.json")) match {
      case Left(error) => {
        println(error.toString)
      }
      case Right(context) => {
        val autoReasoningContext: AutoReasoningContext = context

        val pipeline: AutoReasoningPipelineEngine =
          AutoReasoningPipelineEngine()(spark, autoReasoningContext)

        pipeline.runPipeline("")
      }
    }
  }
}
