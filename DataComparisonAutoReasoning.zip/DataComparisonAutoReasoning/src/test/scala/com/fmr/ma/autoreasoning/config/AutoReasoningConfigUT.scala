package com.fmr.ma.autoreasoning.config

import com.fmr.ma.autoreasoning.datareader.{
  APIDataSource,
  OracleDBDataSource,
  PostgresDataSource,
  S3FileDataSource
}
import org.scalatest.funsuite.AnyFunSuite

import scala.tools.nsc.io.File

class AutoReasoningConfigUT extends AnyFunSuite {
  test("parsing the auto reasoning config file") {
    val configFileInputStream = File("config/part_1.json").inputStream()
    AutoReasoningConfigParsor.parseConfFile(configFileInputStream) match {
      case Left(error) => fail(error)
      case Right(conf) => {
        println(s"json config file ------> ${conf.entity}")
        // data reader
        conf.dataReader.foreach(dr => {
          dr.getDataReaderType match {
            case "Oracle" => {
              val oracleDB = dr.asInstanceOf[OracleDBDataSource]
              println(s"data reader ---type---> ${oracleDB.dataSourceKey}")
            }
            case "Postgres" => {
              val postgresDB = dr.asInstanceOf[PostgresDataSource]
              println(s"data reader ---type---> ${postgresDB.dataSourceKey}")
            }
            case "S3File" => {
              val s3File = dr.asInstanceOf[S3FileDataSource]
              println(s"data reader ---type---> ${s3File.dataSourceKey}")
            }
            case "API" => {
              val apiDataSource = dr.asInstanceOf[APIDataSource]
              println(s"data reader ---type---> ${apiDataSource.dataSourceKey}")
            }
          }
        })
        // product parallel input
        println(
          s"product parallel input------${conf.prodParallelInput.fileType}"
        )

        conf.prodParallelInput.columns.foreach(println)
        // auto reasoning
        conf.autoReasoning.foreach(ar => {
          println(s"auto reasoning---->${ar.column}")
          ar.autoReasoningSequence.foreach(ars => {
            println(
              s"auto reasoning--leftDataSource--query-->${ars.leftDataSource.query}"
            )
            println(
              s"auto reasoning--rightDataSource--query-->${ars.rightDataSource.query}"
            )
            println(
              s"auto reasoning--keyColumns--query-->${ars.keyColumns}"
            )
            println(
              s"auto reasoning--keyColumns--query-->${ars.compareColumns}"
            )
          })
        })
      }
    }
  }
}
