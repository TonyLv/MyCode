package fnb.validation.rule

import better.files.File
import cats.data.Validated
import cats.data.Validated._
import cats.implicits.catsSyntaxSemigroup
import fnb.validation.check._

case class FileValidationCheckRule(
    fileValidationCheckItems: List[FileValidationCheck]
) extends ValidationCheckRule[File] {
  def ruleRun(file: File): Validated[String, String] = {
    // println(s"------------>${fileValidationCheckItems.size}")
    var checkResult: Validated[String, String] = Valid("Good")
    fileValidationCheckItems.foreach(item => {
      item.fileCheck.run(file) match {
        case Right(v) => checkResult |+| Valid("Good")
        case Left(e) => {
          checkResult = checkResult |+| Invalid(e.last)
        }
      }
    })
    checkResult
  }
}
