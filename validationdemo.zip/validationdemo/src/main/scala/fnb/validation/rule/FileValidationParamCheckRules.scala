package fnb.validation.rule

import better.files.File
import cats.data.Validated
import cats.data.Validated.{Invalid, Valid}
import cats.implicits.{catsKernelStdMonoidForString, catsSyntaxSemigroup}
import fnb.validation.check._
import fnb.validation.common.CommonType._

case class FileValidationItem(
    itemName: Int,
    typeName: String,
    value: Option[String]
)

case class FileValidationParamCheckRule(
    checkrule: Option[String],
    colSize: Option[Int],
    delimited: Option[String],
    items: List[FileValidationItem]
) {

  /** This function is used to check the function passed as argument and return
    * the match result as Validated[Errors, String]. If the checkFunction passed
    * returns a Right(v), the matchResult is returned as Valid("Good"). If the
    * checkFunction returns a Left(e), the matchResult is returned as
    * Invalid(e).
    * @param checkFunction
    * @tparam A
    * @return
    */
  private def fileCheckRun[A](
      checkFunction: Result[A]
  ): Validated[Errors, String] = {
    var matchResult: Validated[Errors, String] = Valid("Good")

    checkFunction match {
      case Right(v) => matchResult = Valid("Good")
      case Left(e)  => matchResult = Invalid(e)
    }

    matchResult

  }

  /** runCheck is a function used to check a given File with the passed in
    * parameters. The checkrule parameter is used to determine which type of
    * check should be performed, while the colSize and delimited parameters are
    * used to set the size of the columns and the type of delimiter used,
    * respectively. Lastly, the items parameter is used to specify which items
    * to look for when performing the check.
    *
    * @param file
    *   the file to check
    * @return
    *   a Validated[Errors, String] result indicating whether the check passed
    *   or failed
    */
  def runCheck(file: File): Validated[Errors, String] = {

    var runCheckResult: Validated[Errors, String] = Valid("Good")

    checkrule.getOrElse("") match {
      case "fileEmptyCheck" => {
        val fileEmptyCheck = new FileEmptyValidationWithParamCheck
        runCheckResult =
          runCheckResult |+| fileCheckRun(fileEmptyCheck.fileCheck.run(file))
      }
      case "fileHeaderCheck" => {
        val fileHeaderCheck =
          new FileHeaderValidationWithParamCheck(
            colSize.get,
            delimited.get,
            items
          )
        runCheckResult =
          runCheckResult |+| fileCheckRun(fileHeaderCheck.fileCheck.run(file))
      }
      case "fileTailerCheck" => {
        val fileTailerCheck =
          new FileTailValidationWithParamCheck(
            colSize.get,
            delimited.get,
            items
          )
        runCheckResult =
          runCheckResult |+| fileCheckRun(fileTailerCheck.fileCheck.run(file))
      }
      case _ =>
        runCheckResult = Invalid(
          error(
            "The check rule is wrong, check rule must in the list for ['fileEmptyCheck','fileHeaderCheck','fileTailerCheck']"
          )
        )
    }
    runCheckResult
  }

}

/** FileValidationParamCheckRules is a ValidationCheckRule[File, Errors, String]
  * subclass that checks a given file using a list of
  * FileValidationParamCheckRule objects.
  *
  * It returns a Validated[Errors, String] object with either a "Good" string or
  * a list of errors.
  * @param fileValidationType
  * @param fileValidationParamCheckRules
  */
case class FileValidationParamCheckRules(
    fileValidationType: String,
    fileValidationParamCheckRules: List[FileValidationParamCheckRule]
) extends ValidationCheckRule[File, Errors, String] {
  override def ruleRun(file: File): Validated[Errors, String] = {
    var checkResult: Validated[Errors, String] = Valid("Good")
    fileValidationParamCheckRules.foreach(item => {
      item.runCheck(file) match {
        case Valid(v) => checkResult |+| Valid("Good")
        case Invalid(e) => {
          checkResult = checkResult |+| Invalid(e)
        }
      }
    })
    checkResult
  }
}
