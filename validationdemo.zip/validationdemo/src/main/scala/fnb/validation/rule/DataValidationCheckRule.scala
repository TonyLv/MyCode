package fnb.validation.rule

import cats.data.Validated.{Invalid, Valid}
import cats.data.{NonEmptyList, Validated}
import cats.implicits.{catsKernelStdMonoidForString, catsSyntaxSemigroup}
import fnb.validation.check.DataValidationCheck
import fnb.validation.common.CommonType.DataErrors
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.col

case class DataValidationCheckRule(
    columns: String,
    columnNumber: Int,
    dataValidationCheckItems: List[DataValidationCheck]
) extends ValidationCheckRule[DataFrame, DataErrors, String] {

  /** FileValidationParamCheckRules is a ValidationCheckRule[File, Errors,
    * String] subclass that checks a given file using a list of
    * FileValidationParamCheckRule objects.
    *
    * It returns a Validated[Errors, String] object with either a "Good" string
    * or a list of errors.
    * @param df
    * @return
    */
  override def ruleRun(df: DataFrame): Validated[DataErrors, String] = {

    // 1-Step: set the column name for dataframe

    val schemaArray = columns.split(",")
    val columnArray = df.columns

    var checkResult: Validated[DataErrors, String] = Valid("true")

    if (schemaArray.length == columnArray.length) {
      val colMapSchema = columnArray.zip(schemaArray).toMap

      val newColumnDf = df.select(colMapSchema.map { case (oldCol, newCol) =>
        col(oldCol).as(newCol)
      } toSeq: _*)

      dataValidationCheckItems.foreach(item => {
        item.dataCheck.run(newColumnDf) match {
          case Right(v) => checkResult
          case Left(e) => {
            checkResult = checkResult |+| Invalid(e)
          }
        }
      })

    } else checkResult = Invalid(NonEmptyList.one(df))

    checkResult
  }
}
