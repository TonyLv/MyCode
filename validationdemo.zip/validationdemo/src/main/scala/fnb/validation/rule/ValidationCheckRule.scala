package fnb.validation.rule

import cats.data.Validated

trait ValidationCheckRule[A, B, C] {
  def ruleRun(a: A): Validated[B, C]
}
