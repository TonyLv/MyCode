package fnb.validation.rule

import better.files.File
import cats.data.Validated

trait ValidationCheckRule[A] {
  def ruleRun(a: A): Validated[String, String]
}
