package fnb.validation

object HelloScala extends App {

  var listStr = List(232, 34343)

  print(listStr.flatMap(_ + "fff"))

  var optionList = List(Some("fefe"), Some(""))

  optionList.flatMap {
    case cc => println(cc.value); cc.value
    case _  => None
  }

  println("Hello Scala")
}
