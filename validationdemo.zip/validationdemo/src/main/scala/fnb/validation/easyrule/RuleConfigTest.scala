package fnb.validation.easyrule

import org.apache.spark.sql.SparkSession
import org.jeasy.rules.api.Rules
import org.jeasy.rules.mvel.{MVELRule, MVELRuleFactory}
import org.jeasy.rules.support.reader.YamlRuleDefinitionReader
import org.jeasy.rules.api.Facts
import org.jeasy.rules.api.RulesEngine
import org.jeasy.rules.core.DefaultRulesEngine
import pureconfig._
import pureconfig.generic.auto._

import java.io.FileReader

object RuleConfigTest extends App {

  case class Person(name: String, age: Int, adult: Boolean)

  val tom = new Person("Tom", 14, false)

  val facts = new Facts
  facts.put("person", tom)

  val ruleFactory = new MVELRuleFactory(new YamlRuleDefinitionReader)

  val alcoholRule = ruleFactory.createRule(
    new FileReader("src/main/resources/alcohol-rule.yml")
  )
  println(alcoholRule.getDescription)

  // create rules
  var ageRule = new MVELRule()
    .name("age rule")
    .description(
      "Check if person's age is <> 18 and mark the person as not adult"
    )
    .when("person.age < 18")
    .`then`(
      "System.out.println('Shop: Sorry, you are not allowed to buy alcohol');"
    )

  // create a rule set
  var rules = new Rules;

  // rules.register(ageRule)
  rules.register(alcoholRule)

  // create a default rules engine and fire rules on known facts//create a default rules engine and fire rules on known facts

  val rulesEngine = new DefaultRulesEngine

  println("Tom: Hi! can I have some Vodka please?")
  rulesEngine.fire(rules, facts)
}
