package fnb.validation.easyrule

object RuleConfigTestForFile extends App {}
