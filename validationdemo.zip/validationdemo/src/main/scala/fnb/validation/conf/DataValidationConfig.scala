package fnb.validation.conf

import com.typesafe.scalalogging.LazyLogging
import fnb.validation.check._
import fnb.validation.rule.DataValidationCheckRule
import io.circe._

import java.io.InputStream
import scala.tools.nsc.io.File

case class DataValidationConfig(
    columns: Option[String],
    columnNumber: Option[Int],
    columnChecksRules: List[DataValidationCheck]
) extends ValidationConfig
    with LazyLogging {

  // run data validation rule to check the file
  def runDataValidationCheckRule(): DataValidationCheckRule = {
    DataValidationCheckRule(columns.get, columnNumber.get, columnChecksRules)
  }
}

object DataValidationConfig extends LazyLogging {

  implicit val decodeDataValidationCheck: Decoder[DataValidationCheck] =
    Decoder.instance { cursor =>
      cursor.downField("type").as[String].flatMap {
        case "lengthCheck" =>
          for {
            columnName <- cursor.downField("columnName").as[String]
            length     <- cursor.downField("length").as[Int]
          } yield DataColumnLengthCheck(columnName, length)
        case "columnValueCheck" =>
          for {
            columnName <- cursor.downField("columnName").as[String]
            values     <- cursor.downField("value").as[List[String]]
          } yield DataColumnValueCheck(columnName, values)
        case "columnDecimalScaleCheck" =>
          for {
            columnName <- cursor.downField("columnName").as[String]
            scale      <- cursor.downField("scale").as[Int]
          } yield DataColumnDecimalScaleCheck(columnName, scale)
        case "columnDateFormatCheck" =>
          for {
            columnName  <- cursor.downField("columnName").as[String]
            datePattern <- cursor.downField("datePattern").as[String]
          } yield DataColumnDateFormatCheck(columnName, datePattern)
        case _ =>
          Left(DecodingFailure("Unknown validation check type", cursor.history))
      }
    }

  implicit val decodeDataValidationConfig: Decoder[DataValidationConfig] =
    Decoder.instance { cursor =>
      for {
        columnList   <- cursor.downField("columnList").as[Option[String]]
        columnNumber <- cursor.downField("columnNumber").as[Option[Int]]
        checks       <- cursor.downField("checks").as[List[DataValidationCheck]]
      } yield DataValidationConfig(columnList, columnNumber, checks)
    }

  // covert the file path to inputstream call the FileInputStreamCommonParserConfig.parseFile implicitly
  implicit def filePathToStreamForData(filePath: String): InputStream = {
    Some(File(filePath).inputStream()).value
  }

  // support the local file to use this method
  def parseFile(
      filePath: String
  ): Either[Error, DataValidationConfig] = {
    InputStreamCommonParserConfig.parseFile(filePath)
  }

  // Support the S3 to use this method
  def parseFileFromInputStream(
      fileInputStream: InputStream
  ): Either[Error, DataValidationConfig] = {
    InputStreamCommonParserConfig.parseFile(fileInputStream)
  }
}
