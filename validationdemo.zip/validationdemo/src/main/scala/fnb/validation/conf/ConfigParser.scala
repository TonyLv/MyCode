package fnb.validation.conf

import io.circe.{Decoder, DecodingFailure, Error, HCursor, Json}
import io.circe.yaml.parser

import scala.io.{BufferedSource, Source}
import scala.util.{Failure, Success, Try}

object ConfigParser {

  implicit val decodeValidationConfig: Decoder[ValidationConfig] = {
    (c: HCursor) =>
      // println(s"---decodeValidationConfig--${c.value}-->")
      for {
        validationType <- c
          .downField("validationType")
          .as[String]
        fileCheckTypesJson <- c
          .downField("fileCheckTypes")
          .as[Option[Json]]
      } yield {
//        println(s"-----validationType--->${validationType}")
        println(s"-----validationRulesStr--->${fileCheckTypesJson}")
        new ValidationConfig(validationType, fileCheckTypesJson)
      }
  }

  def configFromJson(json: Json): Either[DecodingFailure, ValidationConfig] = {
    json.as[ValidationConfig]
  }

  private def bufferContentsAsString(buffer: BufferedSource): String = {
    val contents = buffer.mkString
    buffer.close()
    contents
  }

  private def loadFromFile(filename: String): String = {
    val buffer = Source.fromFile(filename)
    bufferContentsAsString(buffer)
  }

  def parseFile(
      filename: String
  ): Either[Error, ValidationConfig] = {

    Try {
      loadFromFile(filename)
    } match {
      case Success(contents) => parse(contents)
      case Failure(thr) =>
        Left[Error, ValidationConfig](
          DecodingFailure.fromThrowable(thr, List.empty)
        )
    }
  }

  def parse(conf: String): Either[Error, ValidationConfig] = {
    /*    println(s"----conf--->${conf}")

    val jsonStr = parser.parse(conf).toOption.get

    val cursor: HCursor = jsonStr.hcursor

    println(cursor.downField("validationType").as[String])
    println(cursor.downField("fileCheckTypes").focus)

    println(s"----jsonStr--->${jsonStr}")*/
    parser.parse(conf).flatMap(configFromJson)
  }

}
