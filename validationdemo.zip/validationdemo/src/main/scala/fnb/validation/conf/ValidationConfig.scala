package fnb.validation.conf

trait ValidationConfig {}
