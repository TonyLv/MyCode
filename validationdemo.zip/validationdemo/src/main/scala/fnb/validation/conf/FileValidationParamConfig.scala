package fnb.validation.conf

import com.typesafe.scalalogging.LazyLogging
import fnb.validation.rule._
import io.circe.{Decoder, DecodingFailure, Error, HCursor, Json}
import io.circe.yaml.{parser => xmlparser}

import java.io.InputStream
import scala.io.{BufferedSource, Source}
import scala.tools.nsc.io.File
import scala.util.{Failure, Success, Try}

case class FileValidationParamConfig(
    filevalidationtype: String,
    checkrules: List[FileValidationParamCheckRule]
) extends ValidationConfig
    with LazyLogging {
  def createFileValidationParamCheckRules(): FileValidationParamCheckRules = {
    FileValidationParamCheckRules(filevalidationtype, checkrules)
  }
}

object FileValidationParamConfig extends LazyLogging {
  implicit val validatedItemDecoder: Decoder[FileValidationItem] =
    Decoder.instance { c =>
      for {
        item      <- c.get[Int]("item")
        itemType  <- c.get[String]("type")
        itemValue <- c.get[Option[String]]("value")
      } yield FileValidationItem(item, itemType, itemValue)
    }
  implicit val checkRuleDecoder: Decoder[FileValidationParamCheckRule] =
    Decoder.instance { c =>
      for {
        checkrule <- c.get[Option[String]]("checkrule")
        colSize   <- c.get[Option[Int]]("colSize")
        delimited <- c.get[Option[String]]("delimited")
        validatedItems <- c.getOrElse[List[FileValidationItem]](
          "validatedItems"
        )(List.empty)
      } yield FileValidationParamCheckRule(
        checkrule,
        colSize,
        delimited,
        validatedItems
      )
    }
  implicit val fileValidationTypeDecoder: Decoder[FileValidationParamConfig] =
    Decoder.instance { c =>
      for {
        filevalidationtype <- c.get[String]("filevalidationtype")
        checkrules <- c.getOrElse[List[FileValidationParamCheckRule]](
          "checkrules"
        )(List.empty)
      } yield FileValidationParamConfig(filevalidationtype, checkrules)
    }

  // covert the file path to inputstream call the FileInputStreamCommonParserConfig.parseFile implicitly
  implicit def filePathToStream(filePath: String): InputStream = {
    Some(File(filePath).inputStream()).value
  }

  def bufferContentsAsString(buffer: BufferedSource): String = {
    val contents = buffer.mkString
    buffer.close()
    contents
  }

  def loadFromFile(fileInputStream: InputStream): String = {
    val buffer = Source.fromInputStream(fileInputStream)
    bufferContentsAsString(buffer)
  }

  private def parseConfFile(
      fileInputStream: InputStream
  ): Either[Error, FileValidationParamConfig] = {
    logger.info("parse file from inputstream...")
    Try {
      loadFromFile(fileInputStream)
    } match {
      case Success(contents) => parse(contents)
      case Failure(thr) =>
        Left[Error, FileValidationParamConfig](
          DecodingFailure.fromThrowable(thr, List.empty)
        )
    }
  }

  def parse(conf: String): Either[Error, FileValidationParamConfig] = {
    xmlparser.parse(conf).flatMap(fileFromJson)
  }

  def fileFromJson(
      json: Json
  ): Either[DecodingFailure, FileValidationParamConfig] = {
    json.as[FileValidationParamConfig]
  }

  // support the local file to use this method
  def parseFile(
      filePath: String
  ): Either[Error, FileValidationParamConfig] = {
    parseConfFile(filePath)
  }

  // Support the S3 to use this method
  def parseFileFromInputStream(
      fileInputStream: InputStream
  ): Either[Error, FileValidationParamConfig] = {
    parseConfFile(fileInputStream)
  }
}
