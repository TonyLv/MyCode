package fnb.validation.conf

import com.typesafe.scalalogging.LazyLogging
import io.circe.yaml.{parser => xmlparser}
import io.circe.{DecodingFailure, Error, Json}

import java.io.InputStream
import scala.io.{BufferedSource, Source}
import scala.util.{Failure, Success, Try}

/** The common class for parsing config file
  * @tparam A
  *   - Type class A as input, as config file
  * @tparam B
  *   - Type class B as output, as the instance of the config file
  */
trait CommonParserConfig[A, B] {

  def fileFromJson(json: Json): Either[DecodingFailure, B]

  def parseFile(a: A): Either[Error, B]

  def loadFromFile(a: A): String

  def bufferContentsAsString(buffer: BufferedSource): String = {
    val contents = buffer.mkString
    buffer.close()
    contents
  }

  def parse(conf: String): Either[Error, B] = {
    xmlparser.parse(conf).flatMap(fileFromJson)
  }
}

object FileInputStreamCommonParserConfig
    extends CommonParserConfig[InputStream, FileValidationConfig]
    with LazyLogging {

  override def parseFile(
      fileInputStream: InputStream
  ): Either[Error, FileValidationConfig] = {
    logger.info("parse file from inputstream...")
    Try {
      loadFromFile(fileInputStream)
    } match {
      case Success(contents) => parse(contents)
      case Failure(thr) =>
        Left[Error, FileValidationConfig](
          DecodingFailure.fromThrowable(thr, List.empty)
        )
    }
  }

  override def loadFromFile(fileInputStream: InputStream): String = {
    val buffer = Source.fromInputStream(fileInputStream)
    bufferContentsAsString(buffer)
  }

  override def fileFromJson(
      json: Json
  ): Either[DecodingFailure, FileValidationConfig] = {
    json.as[FileValidationConfig]
  }
}

object InputStreamCommonParserConfig
    extends CommonParserConfig[InputStream, DataValidationConfig]
    with LazyLogging {

  override def parseFile(
      fileInputStream: InputStream
  ): Either[Error, DataValidationConfig] = {
    logger.info("parse file from inputstream...")
    Try {
      loadFromFile(fileInputStream)
    } match {
      case Success(contents) => parse(contents)
      case Failure(thr) =>
        Left[Error, DataValidationConfig](
          DecodingFailure.fromThrowable(thr, List.empty)
        )
    }
  }

  override def loadFromFile(fileInputStream: InputStream): String = {
    val buffer = Source.fromInputStream(fileInputStream)
    bufferContentsAsString(buffer)
  }

  override def fileFromJson(
      json: Json
  ): Either[DecodingFailure, DataValidationConfig] = {
    json.as[DataValidationConfig]
  }
}
