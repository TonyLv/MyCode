package fnb.validation.conf

import fnb.validation.check._
import fnb.validation.rule.FileValidationCheckRule
import io.circe.yaml.{parser => xmlparser}
import io.circe._

import scala.io.{BufferedSource, Source}
import scala.util.{Failure, Success, Try}

case class FileValidationConfig(
    fileCheckType: Option[String],
    fileValidationCheckRules: List[Json]
) extends ValidationConfig {

  implicit val decodeFileValidationCheck: Decoder[FileValidationCheck] = {
    (c: HCursor) =>
      // println(s"---decodeValidationConfig--${c.value}-->")
      for {
        fileCheckRule <- c
          .downField("checkrule")
          .as[String]
      } yield {
//        println(
//          s"--decodeFileValidationCheck---fileCheckRule------>${fileCheckRule}"
//        )
        var fileValidationCheckItems: FileValidationCheck =
          new FileEmptyValidationCheck

        fileCheckRule match {
          case "fileEmptyCheck" =>
            fileValidationCheckItems = new FileEmptyValidationCheck
          case "fileHeaderCheck" =>
            fileValidationCheckItems = new FileHeaderValidationCheck
          case "fileTailerCheck" =>
            fileValidationCheckItems = new FileTailerValidationCheck
        }

        fileValidationCheckItems
      }
  }

  def createFileValidationCheckRule(): FileValidationCheckRule = {
    var fileValidationCheckItems: List[FileValidationCheck] = List()
    fileValidationCheckRules.foreach(item => {
      val validationCheckItem = item.as[FileValidationCheck].toOption.get
      fileValidationCheckItems =
        fileValidationCheckItems ::: List(validationCheckItem)
    })
    FileValidationCheckRule(fileValidationCheckItems)
  }
}

object FileValidationConfig {
  implicit val decodeFileValidationConfig: Decoder[FileValidationConfig] = {
    (c: HCursor) =>
      for {
        fileValidationType <- c
          .downField("filevalidationtype")
          .as[Option[String]]
        fileCheckRules <- c
          .downField("checkrules")
          .as[List[Json]]
      } yield {
        new FileValidationConfig(fileValidationType, fileCheckRules)
      }
  }

  def fileFromJson(
      json: Json
  ): Either[DecodingFailure, FileValidationConfig] = {
    json.as[FileValidationConfig]
  }

  private def bufferContentsAsString(buffer: BufferedSource): String = {
    val contents = buffer.mkString
    buffer.close()
    contents
  }

  private def loadFromFile(filename: String): String = {
    val buffer = Source.fromFile(filename)
    bufferContentsAsString(buffer)
  }

  def parseFile(
      filename: String
  ): Either[Error, FileValidationConfig] = {

    Try {
      loadFromFile(filename)
    } match {
      case Success(contents) => parse(contents)
      case Failure(thr) =>
        Left[Error, FileValidationConfig](
          DecodingFailure.fromThrowable(thr, List.empty)
        )
    }
  }

  def parse(
      conf: String
  ): Either[Error, FileValidationConfig] = {
    xmlparser.parse(conf).flatMap(fileFromJson)
  }
}
