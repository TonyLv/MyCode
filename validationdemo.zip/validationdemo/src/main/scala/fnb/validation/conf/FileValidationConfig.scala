package fnb.validation.conf

import com.typesafe.scalalogging.LazyLogging
import fnb.validation.check._
import fnb.validation.rule.FileValidationCheckRule
import io.circe._

import java.io.InputStream
import scala.tools.nsc.io.File

case class FileValidationConfig(
    fileCheckType: Option[String],
    fileValidationCheckRules: List[Json]
) extends ValidationConfig
    with LazyLogging {

  implicit val decodeFileValidationCheck: Decoder[FileValidationCheck] = {
    (c: HCursor) =>
      logger.debug(s"---decodeValidationConfig--${c.value}-->")
      for {
        fileCheckRule <- c
          .downField("checkrule")
          .as[String]
      } yield {
        logger.debug(
          s"--decodeFileValidationCheck---fileCheckRule------>${fileCheckRule}"
        )
        var fileValidationCheckItems: FileValidationCheck =
          new FileEmptyValidationCheck

        fileCheckRule match {
          case "fileEmptyCheck" =>
            fileValidationCheckItems = new FileEmptyValidationCheck
          case "fileHeaderCheck" =>
            fileValidationCheckItems = new FileHeaderValidationCheck
          case "fileTailerCheck" =>
            fileValidationCheckItems = new FileTailerValidationCheck
        }

        fileValidationCheckItems
      }
  }

  def createFileValidationCheckRule(): FileValidationCheckRule = {
    var fileValidationCheckItems: List[FileValidationCheck] = List()
    fileValidationCheckRules.foreach(item => {
      val validationCheckItem = item.as[FileValidationCheck].toOption.get
      fileValidationCheckItems =
        fileValidationCheckItems ::: List(validationCheckItem)
    })
    FileValidationCheckRule(fileValidationCheckItems)
  }
}

object FileValidationConfig {
  implicit val decodeFileValidationConfig: Decoder[FileValidationConfig] = {
    (c: HCursor) =>
      for {
        fileValidationType <- c
          .downField("filevalidationtype")
          .as[Option[String]]
        fileCheckRules <- c
          .downField("checkrules")
          .as[List[Json]]
      } yield {
        new FileValidationConfig(fileValidationType, fileCheckRules)
      }
  }

  // covert the file path to inputstream call the FileInputStreamCommonParserConfig.parseFile implicitly
  implicit def filePathToStream(filePath: String): InputStream = {
    Some(File(filePath).inputStream()).value
  }

  // support the local file to use this method
  def parseFile(
      filePath: String
  ): Either[Error, FileValidationConfig] = {
    FileInputStreamCommonParserConfig.parseFile(filePath)
  }

  // Support the S3 to use this method
  def parseFileFromInputStream(
      fileInputStream: InputStream
  ): Either[Error, FileValidationConfig] = {
    FileInputStreamCommonParserConfig.parseFile(fileInputStream)
  }
}
