package fnb.validation

import better.files.File
import cats.data.{NonEmptyList, Validated}
import cats.data.Validated.{Invalid, Valid}
import com.typesafe.scalalogging.LazyLogging
import fnb.validation.common.CommonType
import fnb.validation.common.CommonType._
import fnb.validation.conf.{DataValidationConfig, FileValidationParamConfig}
import org.apache.spark.sql.DataFrame

import java.io.InputStream

object ValidationTools extends LazyLogging {

  /** This function doFileValidation is used to validate a given file based on
    * the configuration provided in an InputStream.
    *
    * First it parses the config from the InputStream and gets the
    * FileValidationParamCheckRules from the config.
    *
    * Then it applies the rules to the given file.
    *
    * If the validation passes, it returns a Valid status with "pass" String.
    * Else it returns an Invalid status with errors.
    * @param conf
    * @param file
    * @return
    */
  def doFileValidation(
      conf: InputStream,
      file: File
  ): Validated[Errors, String] = {
    var retValue: Validated[Errors, String] = Valid("pass")

    FileValidationParamConfig.parseFileFromInputStream(conf) match {
      case Left(pe) =>
        retValue = Invalid(
          error("Config file parse error, please check it")
        )
      case Right(config) => {
        config.createFileValidationParamCheckRules().ruleRun(file) match {
          case Valid(a)   => retValue = Valid("pass")
          case Invalid(e) => retValue = Invalid(e)
        }
      }
    }
    retValue
  }

  /** This function takes an InputStream and DataFrame as inputs and does data
    * validation for Spark.
    *
    * The function will parse the InputStream and convert the config file into a
    * CheckRule. It then runs the CheckRule on the DataFrame to check if any
    * issues arise.
    *
    * If any issues are found, it will return an Invalid containing the data
    * errors. If everything passes, it will return a Valid string "pass".
    * @param conf
    * @param df
    * @return
    */
  def doDataValidationForSpark(
      conf: InputStream,
      df: DataFrame
  ): Validated[DataErrors, String] = {
    var retValue: Validated[DataErrors, String] = Valid("pass")
    DataValidationConfig.parseFileFromInputStream(conf) match {
      case Right(checkRule) => {
        checkRule.runDataValidationCheckRule().ruleRun(df) match {
          case Valid(a)   => retValue = Valid("pass")
          case Invalid(e) => retValue = Invalid(e)
        }
      }
      case Left(pe) =>
        retValue = Invalid(
          errorWithData(df, "Config file parse error, please check it")
        )
    }
    retValue
  }
}
