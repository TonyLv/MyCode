package fnb.validation.check

import better.files.File
import com.typesafe.scalalogging.LazyLogging
import fnb.validation.common.CommonType.Check
import fnb.validation.predicate.FileValidationPredicate._
import fnb.validation.rule.FileValidationItem

abstract class FileValidationWithParamCheck
    extends ValidationCheck
    with LazyLogging {

  /** This function is used to check if a given file exists and can be read. It
    * will return a File object if the check is successful, and an error if not.
    * @return
    */
  def fileCheck: Check[File, File]
}

case class FileEmptyValidationWithParamCheck()
    extends FileValidationWithParamCheck {

  logger.info("To check the file empty or not")

  def fileCheck: Check[File, File] = {
    checkPred(
      fileNotEmpty
    )
  }
}

/** This class is used to validate the file header with parameters to be
  * compliant with defined rules.
  *
  * The method "fileCheck" is used to check if the file header has the required
  * values and is accurate.
  * @param colSize
  * @param delimited
  * @param items
  */
case class FileHeaderValidationWithParamCheck(
    colSize: Int,
    delimited: String,
    items: List[FileValidationItem]
) extends FileValidationWithParamCheck {

  logger.info("To check the file header with param to suit the rule")

  def fileCheck: Check[File, File] = {
    checkPred(
      fileHeaderValueValidated(colSize, delimited, items)
    )
  }
}

/** FileTailValidationWithParamCheck is a class which extends the
  * FileValidationWithParamCheck interface to check the file tail with the rules
  * provided. It takes in the column size, delimiter and the list of
  * FileValidationItems as parameters and its fileCheck method validate the file
  * accordingly.
  * @param colSize
  * @param delimited
  * @param items
  */
case class FileTailValidationWithParamCheck(
    colSize: Int,
    delimited: String,
    items: List[FileValidationItem]
) extends FileValidationWithParamCheck {

  logger.info("To check the file tail with param to suit the rule")

  def fileCheck: Check[File, File] = {
    checkPred(
      fileTailorValueValidated(
        colSize,
        delimited,
        items: List[FileValidationItem]
      )
    )
  }
}
