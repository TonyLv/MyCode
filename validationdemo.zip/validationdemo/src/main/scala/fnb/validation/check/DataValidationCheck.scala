package fnb.validation.check

import com.typesafe.scalalogging.LazyLogging
import fnb.validation.common.CommonType._
import fnb.validation.predicate.DataValidationPredicate._
import org.apache.spark.sql.DataFrame

import scala.collection.{Seq => scalaSeq}

abstract class DataValidationCheck extends ValidationCheck {
  def dataCheck: DataCheck[DataFrame, DataFrame]
}

/** Check the column number for data file
  * @param newCols
  */
case class DataColumnNumberCheck(newCols: String)
    extends DataValidationCheck
    with LazyLogging {
  override def dataCheck: DataCheck[DataFrame, DataFrame] = {
    logger.info("checking the number of columns for data file")
    checkPredForData(validateNumberOfColumns(newCols))
  }
}

/** Check data column value for mandatory data value.
  * @param col
  * @param colValues
  */
case class DataColumnValueCheck(col: String, colValues: scalaSeq[String])
    extends DataValidationCheck
    with LazyLogging {
  override def dataCheck: DataCheck[DataFrame, DataFrame] = {
    logger.info("checking the value of columns for data file")
    checkPredForData(validatedColValue(col, colValues))
  }
}

/** Check data column fit the length of column we required.
  * @param col
  * @param colLength
  */
case class DataColumnLengthCheck(col: String, colLength: Int)
    extends DataValidationCheck
    with LazyLogging {
  override def dataCheck: DataCheck[DataFrame, DataFrame] = {
    logger.info("check data column fit the length of column we required")
    checkPredForData(valiatedColLength(col, colLength))
  }
}

/** Check data column should have exactly scale when we met the decimal type
  * @param col
  * @param scaleLength
  */
case class DataColumnDecimalScaleCheck(col: String, scaleLength: Int)
    extends DataValidationCheck
    with LazyLogging {
  override def dataCheck: DataCheck[DataFrame, DataFrame] = {
    logger.info(
      "check data column should have exactly scale when we met the decimal type"
    )
    checkPredForData(validateColDecimalScale(col, scaleLength))
  }
}

/** Check the column should be given date pattern
  * @param col
  * @param datePattern
  */
case class DataColumnDateFormatCheck(col: String, datePattern: String)
    extends DataValidationCheck
    with LazyLogging {
  override def dataCheck: DataCheck[DataFrame, DataFrame] = {
    logger.info(
      s"check data column should have $datePattern format"
    )
    checkPredForData(validateColDateFormat(col, datePattern))
  }
}
