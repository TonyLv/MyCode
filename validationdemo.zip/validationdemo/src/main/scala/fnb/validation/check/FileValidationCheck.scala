package fnb.validation.check

import better.files.File
import com.typesafe.scalalogging._
import fnb.validation.common.CommonType.Check
import fnb.validation.predicate.FileValidationPredicate._

abstract class FileValidationCheck extends ValidationCheck with LazyLogging {
  def fileCheck: Check[File, File]
}

case class FileHeaderValidationCheck() extends FileValidationCheck {

  logger.info("To check the file header to suit the rule")

  def fileCheck: Check[File, File] = {
    checkPred(
      fileNotEmpty and fileHasRightHeader
    )
  }
}

case class FileTailerValidationCheck() extends FileValidationCheck {

  logger.info("To check the file tailer to suit the rule")

  def fileCheck: Check[File, File] = {
    checkPred(
      fileNotEmpty and fileHasRightTail
    )
  }
}

case class FileEmptyValidationCheck() extends FileValidationCheck {

  logger.info("To check the file empty or not")

  def fileCheck: Check[File, File] = {
    checkPred(
      fileNotEmpty
    )
  }
}
