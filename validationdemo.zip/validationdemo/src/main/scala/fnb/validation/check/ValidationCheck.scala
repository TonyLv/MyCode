package fnb.validation.check

import better.files.File
import cats.data.Kleisli
import fnb.validation.predicate.ValidatePredicate
import fnb.validation.predicate.FileValidationPredicate._
import cats.syntax.all._
import org.joda.time.format.DateTimeFormat
import fnb.validation.common.CommonType._

import scala.util.{Failure, Success, Try}
import scala.util.matching.Regex

trait ValidationCheck {

  def check[A, B](func: A => Result[B]): Check[A, B] =
    Kleisli(func)

  def checkPred[A](pred: ValidatePredicate[Errors, A]): Check[A, A] =
    Kleisli[Result, A, A](pred.run)
}

case class FileValidationCheck(file: File) extends ValidationCheck {

  var fileName = file.name

  def commonFileFormatCheck: Check[File, File] = {
    checkPred(
      fileNotEmpty(fileName) and fileHasRightHeader and fileHasRightTail
    )
  }

  def commonFileEmptyCheck: Check[File, File] = {
    checkPred(fileNotEmpty(fileName))
  }
}

case class DataValidationCheck() extends ValidationCheck {}
