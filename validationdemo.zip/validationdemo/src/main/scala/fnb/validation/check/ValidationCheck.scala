package fnb.validation.check

import better.files.File
import cats.data.Kleisli
import fnb.validation.predicate.ValidatePredicate
import fnb.validation.predicate.FileValidationPredicate._
import cats.syntax.all._
import fnb.validation.common.CommonType._

trait ValidationCheck {

  def check[A, B](func: A => Result[B]): Check[A, B] =
    Kleisli(func)

  def checkPred[A](pred: ValidatePredicate[Errors, A]): Check[A, A] =
    Kleisli[Result, A, A](pred.run)
}
