package fnb.validation.common

import cats.data.{Kleisli, NonEmptyList}
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.lit

object CommonType {

  // Define Errors type
  type Errors     = NonEmptyList[String]
  type DataErrors = NonEmptyList[DataFrame]

  // Define Errors functions
  def error(s: String): NonEmptyList[String] =
    NonEmptyList(s, Nil)

  // Define Errors function to output the error with data
  def errorWithData(
      dataFrame: DataFrame,
      s: String
  ): NonEmptyList[DataFrame] = {

    val newDataFrame = dataFrame.withColumn("ERR_DATA", lit(s))

    NonEmptyList(newDataFrame, Nil)
  }

  // Define Result type from Either Type
  type Result[A] = Either[Errors, A]

  // Define the meaningful type for data Result
  type DataResult[A] = Either[DataErrors, A]

  // Define Result type from Kleisli Type
  type Check[A, B] = Kleisli[Result, A, B]

  // Define Check type for data from Kleisli Type
  type DataCheck[A, B] = Kleisli[DataResult, A, B]

}
