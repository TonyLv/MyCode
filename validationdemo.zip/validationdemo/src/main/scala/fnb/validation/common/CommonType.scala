package fnb.validation.common

import cats.data.{Kleisli, NonEmptyList}

object CommonType {

  type Errors = NonEmptyList[String]

  def error(s: String): NonEmptyList[String] =
    NonEmptyList(s, Nil)

  type Result[A] = Either[Errors, A]

  type Check[A, B] = Kleisli[Result, A, B]

}
