package fnb.validation.predicate.expr
import org.apache.spark.sql.catalyst.analysis.UnresolvedAttribute
import org.apache.spark.sql.catalyst.expressions._
import org.apache.spark.sql.types.IntegerType

/** Compare to the column length from giving length
  * @param column
  *   - Column from Dataframe
  * @param lenValue
  *   - Real length for this column
  */
case class CondLengthOfCol(column: String, lenValue: Int)
    extends CondDataBaseSpark {
  override def colCond(): Expression = {
    EqualTo(
      Length(UnresolvedAttribute(column)),
      Literal.create(lenValue, IntegerType)
    )
  }
}
