package fnb.validation.predicate.expr
import org.apache.spark.sql.catalyst.analysis.UnresolvedAttribute
import org.apache.spark.sql.catalyst.expressions.{Expression, Literal, RLike}

/** To find the right data to fit the date pattern
  * @param colName
  * @param dateRegex
  */
case class CondColDateFormat(colName: String, dateRegex: String)
    extends CondDataBaseSpark {
  override def colCond(): Expression = {
    RLike(UnresolvedAttribute(colName), Literal.create(dateRegex))
  }
}
