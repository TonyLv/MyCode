package fnb.validation.predicate

import cats.Semigroup
import cats.data.Validated
import cats.data.Validated._
import cats.implicits._
import fnb.validation.common.CommonType._

/** ValidatePredicate which can be combined using logical operations such as and
  * and or.
  *
  * It can create the chain rule through ValidatePredicate
  */
trait ValidatePredicate[E, A] {

  import ValidatePredicate._

  def run(implicit s: Semigroup[E]): A => Either[E, A] = (a: A) =>
    this(a).toEither

  def and(that: ValidatePredicate[E, A]): ValidatePredicate[E, A] =
    And(this, that)

  def or(that: ValidatePredicate[E, A]): ValidatePredicate[E, A] =
    Or(this, that)

  def apply(a: A)(implicit s: Semigroup[E]): Validated[E, A] =
    this match {
      case Pure(func) =>
        func(a)

      case And(left, right) =>
        (left(a), right(a)).mapN((_, _) => a)

      case Or(left, right) =>
        left(a) match {
          case Valid(a1) => Valid(a)
          case Invalid(e1) =>
            right(a) match {
              case Valid(a2)   => Valid(a)
              case Invalid(e2) => Invalid(e1 |+| e2)
            }
        }
    }
}

object ValidatePredicate {

  final case class And[E, A](
      left: ValidatePredicate[E, A],
      right: ValidatePredicate[E, A]
  ) extends ValidatePredicate[E, A]

  final case class Or[E, A](
      left: ValidatePredicate[E, A],
      right: ValidatePredicate[E, A]
  ) extends ValidatePredicate[E, A]

  final case class Pure[E, A](func: A => Validated[E, A])
      extends ValidatePredicate[E, A]

  def apply[E, A](f: A => Validated[E, A]): ValidatePredicate[E, A] =
    Pure(f)

  def lift[E, A](err: E, fn: A => Boolean): ValidatePredicate[E, A] =
    Pure(a => if (fn(a)) a.valid else err.invalid)

  /** liftError is the function which it can be set error from the fn
    * @param err
    * @param fn
    * @tparam E
    * @tparam A:
    * @return
    */
  def liftError[E, A](
      fn: A => Either[E, Boolean]
  ): ValidatePredicate[E, A] =
    Pure(a => {
      fn(a) match {
        case Right(flag)        => a.valid
        case Left(errorMessage) => errorMessage.invalid
      }
    })
}
