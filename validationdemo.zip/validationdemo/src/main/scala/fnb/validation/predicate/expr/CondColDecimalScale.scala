package fnb.validation.predicate.expr
import org.apache.spark.sql.catalyst.analysis.UnresolvedAttribute
import org.apache.spark.sql.catalyst.expressions.{
  EqualTo,
  Expression,
  Length,
  Literal,
  RegExpExtract
}

case class CondColDecimalScale(column: String, scaleLength: Int)
    extends CondDataBaseSpark {
  override def colCond(): Expression = {
    /*    EqualTo(
      Cast(UnresolvedAttribute(column), new DecimalType()),
      Literal.create(scaleLength)
    )*/

    EqualTo(
      Length(
        RegExpExtract(
          UnresolvedAttribute(column),
          Literal.create("(\\d+).(\\d+)"),
          Literal.create(2)
        )
      ),
      Literal.create(scaleLength)
    )

  }
}
