package fnb.validation.predicate.expr

import org.apache.spark.sql.catalyst.expressions.{Expression, If, Literal}
import org.apache.spark.sql.types.{DoubleType, IntegerType, LongType}

abstract class CondDataBaseSpark {
  // set up the Literal class to support integer, Long and double type.
  val I0: Literal = Literal.create(0, IntegerType)
  val D0: Literal = Literal.create(0.0, DoubleType)
  val L0: Literal = Literal.create(0L, LongType)
  val L1: Literal = Literal.create(1L, LongType)

  // to validate the cols for schema from dataframe
  def colCond(): Expression

  // select cols to call to validate col
  def select(): Expression = If(colCond(), L1, L0)

}
