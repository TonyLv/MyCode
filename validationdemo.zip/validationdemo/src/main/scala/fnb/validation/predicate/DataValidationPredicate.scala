package fnb.validation.predicate

import com.typesafe.scalalogging._
import fnb.validation.common.CommonType._
import fnb.validation.predicate.expr._
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.catalyst.expressions.Not
import org.apache.spark.sql.functions.col

import scala.collection.{Seq => scalaSeq}
import scala.util.{Failure, Success, Try}

/** This class is for data validation from input Dataframe
  */
abstract class DataValidationPredicate {}
object DataValidationPredicate extends LazyLogging {

  val dateFormatMap = Map(
    "YYYY-MM-DD" -> """^[0-9]{4}-(((0[13578]|(10|12))-(0[1-9]|[1-2][0-9]|3[0-1]))|(02-(0[1-9]|[1-2][0-9]))|((0[469]|11)-(0[1-9]|[1-2][0-9]|30)))$""",
    "DD/MM/YYYY" -> """(?:(?:31(-)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(-)(?:0?[13-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(-)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(-)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})""",
    "MM/DD/YYYY" -> """^(0[1-9]|[1-9]|1[0-2])\/(0[1-9]|[1-9]|1\d|2\d|3[01])\/(20|21)\d{2}$"""
  )

  /** Set meaningful column name to dataframe
    * @param oldDataFrame
    *   \- original dataframe as input
    * @param newColumnStr
    *   \- new columns combine with "," for new dataframe, like "newCol1,
    *   newCol2,...,newColn"
    * @return
    *   Either[Errors, DataFrame]: when column cast exception happen, return
    *   error.
    */
  def setUserDefinedColumn(
      oldDataFrame: DataFrame,
      newColumnStr: String
  ): Either[Errors, DataFrame] = {

    var newDataFrame = oldDataFrame

    var ret: Either[Errors, DataFrame] = Left(error(""))

    val oldColumnArray = oldDataFrame.columns
    val newColumnArray = newColumnStr.split(",")

    if (oldColumnArray.length == newColumnArray.length) {
      // create the Map (oldCol -> newCol)
      val oldColMapNewCol = oldColumnArray.zip(newColumnArray).toMap
      // set the new columns
      Try(newDataFrame = oldDataFrame.select(oldColMapNewCol.map {
        case (oldCol, newCol) =>
          col(oldCol).as(newCol)
      } toSeq: _*)) match {
        case Success(value) => ret = Right(newDataFrame)
        case Failure(exception) => {
          logger.error(exception.getMessage)
          ret = Left(error("Mandatory data fields are populated!"))
        }
      }
    }
    ret
  }

  /** To validation the number of columns from Dataframe as predicate
    * @param columnsStr
    *   \- the collection of columns format like this "column1, column2,
    *   columns3" that split by ','.
    * @return
    *   if the invalidate, it output the Errors and if the validate, output the
    *   DataFrame
    */
  def validateNumberOfColumns(
      columnsStr: String
  ): ValidatePredicate[DataErrors, DataFrame] = {
    ValidatePredicate.liftError(df => {

      var validateResult: Either[DataErrors, Boolean] = Right(true)

      val columnsStrArray = columnsStr.split(",")

      val columnsNumber              = columnsStrArray.length
      val columnsNumberFromDataframe = df.columns.length

      validateResult = if (columnsNumber != columnsNumberFromDataframe) {
        logger.info(s"The number of data fields is not the right!")
        Left(errorWithData(df, s"The number of data fields is not the right!"))
      } else {
        Right(true)
      }
      validateResult
    })
  }

  /** As predicate, to validate the length of column from length Find the
    * records as output which colName's lenght != colLen
    * @param colName
    * @param colLen
    * @return
    */
  def valiatedColLength(
      colName: String,
      colLen: Int
  ): ValidatePredicate[DataErrors, DataFrame] = {

    ValidatePredicate.liftError(df => {

      var retResult: Either[DataErrors, Boolean] = Right(true)

      val lengthOfCond = new CondLengthOfCol(colName, colLen)
      // logger.debug(df.filter(lengthOfCond.colCond().sql).show().toString)

      val newDf = df.filter(Not(lengthOfCond.colCond()).sql)

      if (newDf.count() != 0L) {
        logger.info(s"$colName should be of length $colLen")
        retResult =
          Left(errorWithData(newDf, s"$colName should be of length $colLen"))
      }

      retResult

    })
  }

  /** To validate the certain column should a list of configured certain value.
    * @param colName
    * @param colValue
    * @return
    */
  def validatedColValue(
      colName: String,
      colValues: scalaSeq[String]
  ): ValidatePredicate[DataErrors, DataFrame] = {
    ValidatePredicate.liftError(df => {
      var retResult: Either[DataErrors, Boolean] = Right(true)

      val colValueCond = new CondColValue(colName, colValues)

      val newDf = df.filter(Not(colValueCond.colCond()).sql)

      if (newDf.count() != 0L) {
        logger.info(s"$colName should a list of configured ${colValues}")
        retResult = Left(
          errorWithData(
            newDf,
            s"$colName should a list of configured ${colValues}"
          )
        )
      }
      retResult
    })
  }

  /** To validate certain decimal of column has the `scaleLength` scale
    * @param colName
    * @param scaleLength
    * @return
    */
  def validateColDecimalScale(
      colName: String,
      scaleLength: Int
  ): ValidatePredicate[DataErrors, DataFrame] = {
    ValidatePredicate.liftError(df => {
      var retResult: Either[DataErrors, Boolean] = Right(true)

      val colDecimalCond = new CondColDecimalScale(colName, scaleLength)

      val newDf = df.filter(Not(colDecimalCond.colCond()).sql)

      logger.debug(newDf.explain(mode = "formatted").toString)

      if (newDf.count() != 0L) {
        logger.info(s"$colName should have exactly $scaleLength decimal scale")
        retResult = Left(
          errorWithData(
            newDf,
            s"$colName should have exactly $scaleLength decimal scale"
          )
        )
      }

      retResult
    })
  }

  /** The date column should have right date format
    * @param colName
    * @param dateRegex
    *   - YYYY-MM-DD or DD/MM/YYYY
    * @return
    */
  def validateColDateFormat(
      colName: String,
      dateRegex: String
  ): ValidatePredicate[DataErrors, DataFrame] = {
    ValidatePredicate.liftError(df => {

      var retResult: Either[DataErrors, Boolean] = Right(true)

      dateFormatMap.get(dateRegex) match {
        case Some(dateRg) => {
          val colDateFormat = new CondColDateFormat(colName, dateRg)

          val newDf = df.filter(Not(colDateFormat.colCond()).sql)

          if (newDf.count() != 0L) {
            logger.info(s"$colName should be $dateRegex formate")
            retResult = Left(
              errorWithData(
                newDf,
                s"$colName should be $dateRegex formate"
              )
            )
          }
        }
        case None => {
          logger.error(s"$dateRegex is not right date format")
          retResult = Right(false)
        }
      }

      retResult
    })
  }
}
