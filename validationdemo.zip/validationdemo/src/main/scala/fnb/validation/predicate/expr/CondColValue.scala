package fnb.validation.predicate.expr
import org.apache.spark.sql.catalyst.analysis.UnresolvedAttribute
import org.apache.spark.sql.catalyst.expressions.{Expression, In, Literal}

/** Match list of configured values like Seq["N", "Y"] or single value Seq["0"]
  * @param column
  *   Column from dataframe
  * @param value
  *   value is Seq for listing of configured values
  */
case class CondColValue(column: String, value: Seq[String])
    extends CondDataBaseSpark {
  override def colCond(): Expression = {
    In(UnresolvedAttribute(column), value.map(v => Literal.create(v)))
  }
}
