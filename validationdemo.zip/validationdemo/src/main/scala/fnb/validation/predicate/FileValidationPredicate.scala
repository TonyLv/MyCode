package fnb.validation.predicate

import better.files.File
import com.typesafe.scalalogging._
import fnb.validation.common.CommonType._
import fnb.validation.rule.FileValidationItem

import java.time.format.DateTimeFormatter
import scala.util.matching.Regex
import scala.util.{Failure, Success, Try}

/** FileValidationPredicate is the class including the different predicates for
  * file validation
  */
class FileValidationPredicate {}

object FileValidationPredicate extends LazyLogging {

  // File header date format
  val fileHeaderDateFormat = DateTimeFormatter.ofPattern("yyyyMMdd")
  // Regex: for header
  val headerPattern: Regex = """H,\w+,\d{8}""".r
  // Regex: for tailor
  val tailPattern: Regex = """T,\d+""".r
  // Regex: for number
  val numberPattern: Regex = """\d{8}""".r
  // Regex: for tailor number pattern
  val numberTailPattern: Regex = """\d+""".r

  // Predicate one: File should not be empty
  def fileNotEmpty: ValidatePredicate[Errors, File] =
    ValidatePredicate.lift(
      error(s"File should not be empty!"),
      file => file.nonEmpty
    )

  /** fileHeaderCheck function check the file have right formatted header or not
    * @param file
    * @return
    *   Either[Errors, Boolean]: if the file is not the right header, it's
    *   return Errors
    */
  private def fileHeaderCheck(file: File): Either[Errors, Boolean] = {
    val fileName = file.name
    if (!file.isEmpty) {
      val header = file.lineIterator.next()
      // checking the header's format ---"""H,\w+,\d{8}"""
      headerPattern.findFirstMatchIn(header) match {
        case Some(_) => {
          var headerDateCheckResult: Either[Errors, Boolean] = Right(true)
          header.split(",").foreach { item =>
            // checking the date for the header --- """\d{8}"""
            numberPattern.findFirstMatchIn(item) match {
              case Some(headerItem) => {
                // Using the Try to capture the error when the date format is wrong
                Try(
                  fileHeaderDateFormat.parse(headerItem.toString())
                ) match {
                  case Success(v) => headerDateCheckResult = Right(true)
                  case Failure(e) =>
                    logger.debug(
                      s"$fileName header should have a right date format[yyyyMMdd]!"
                    )
                    headerDateCheckResult = Left(
                      error(
                        s"$fileName header should have a right date format[yyyyMMdd]!"
                      )
                    )
                }
                headerDateCheckResult
              }
              case None =>
                logger.debug(
                  s"$fileName header should have a right date format[yyyyMMdd]!"
                )
                headerDateCheckResult = Left(
                  error(
                    s"$fileName header should have a right date format[yyyyMMdd]!"
                  )
                )
            }
          }
          headerDateCheckResult
        }
        case None => {
          logger.debug(
            s"$fileName had bad header!"
          )
          Left(error(s"$fileName had bad header!"))
        }
      }
    } else {
      logger.debug(
        s"$fileName is empty"
      )
      Left(error(s"$fileName is empty"))
    }
  }

  /** fileHeaderCheck function check the file have right formatted tail or not
    * @param file
    * @return
    */
  private def fileTailCheck(file: File): Either[Errors, Boolean] = {
    val fileName = file.name
    if (!file.isEmpty) {
      val fileLineNumber = file.lineCount - 2
      val fileLineCount  = file.lineCount.toInt
      val tailContent =
        file.lineIterator.slice(fileLineCount - 1, fileLineCount).next()

      tailPattern.findFirstMatchIn(tailContent) match {
        case Some(_) => {
          var tailCheckResult: Either[Errors, Boolean] = Right(true)
          val tailContentItem = tailContent.split(",").last
          // println(s"--tailContentItems----$tailContentItem")
          if (fileLineNumber != tailContentItem.toLong) {
            logger.debug(
              s"$fileName should have the right number of the record"
            )
            tailCheckResult = Left(
              error(s"$fileName should have the right number of the record")
            )
          }
          tailCheckResult
        }
        case None => {
          logger.debug(
            s"$fileName should have the right tail-2"
          )
          Left(error(s"$fileName should have the right tail-2"))
        }
      }
    } else {
      logger.debug(
        s"$fileName should have the right tail-3"
      )
      Left(error(s"$fileName should have the right tail-3"))
    }
  }

  /** The common method for validated file header or tail
    * @param fileName
    * @param itemsZip
    * @param hOrTFlag
    *   /- "header" for file header validate or "tail" for file tail validate
    * @param fileLineNumber
    *   /- if the hOrTFlag is tail, the fileLineNumber indicate the number of
    *   rows of file
    * @return
    */
  private def commonValueValidated(
      fileName: String,
      itemsZip: List[(FileValidationItem, String)],
      hOrTFlag: String,
      fileLineNumber: Option[Long]
  ): Either[Errors, Boolean] = {

    var retValue: Either[Errors, Boolean] = Right(true)

    itemsZip.foreach({
      case (fileValidationItem, value)
          if fileValidationItem.typeName.equals("valueValidated") => {
        if (fileValidationItem.value.getOrElse("").equals(value)) {
          retValue = Right(true)
        } else {
          retValue = Left(
            error(
              s"$fileName should right $hOrTFlag format, the $hOrTFlag column should be ${fileValidationItem.value
                  .getOrElse("")}"
            )
          )
        }
      }
      case (fileValidationItem, value)
          if fileValidationItem.typeName.equals("dateValidated") => {
        val fileDateFormat =
          DateTimeFormatter.ofPattern(fileValidationItem.value.getOrElse(""))

        Try(
          fileDateFormat.parse(value)
        ) match {
          case Success(v) => retValue = Right(true)
          case Failure(e) =>
            logger.debug(
              s"$fileName $hOrTFlag should have a right date format[yyyyMMdd]!"
            )
            retValue = Left(
              error(
                s"$fileName $hOrTFlag should have a right date format[yyyyMMdd]!"
              )
            )
        }
      }
      case (fileValidationItem, value)
          if fileValidationItem.typeName.equals("sumValidated") => {
        if (fileLineNumber.getOrElse(0) != value.toLong) {
          logger.debug(
            s"$fileName should have the right number of the record"
          )
          retValue = Left(
            error(s"$fileName should have the right number of the record")
          )
        } else {
          retValue = Right(true)
        }
      }
    })
    retValue
  }

  /** fileTailorValueValidated to validate the input file tailer has the right
    * value
    * @return
    */
  def fileTailorValueValidated(
      colSize: Int,
      delimited: String,
      items: List[FileValidationItem]
  ): ValidatePredicate[Errors, File] = {
    ValidatePredicate.liftError(file => {

      var retValue: Either[Errors, Boolean] = Right(true)

      /** This code checks the tail content of the file for the appropriate
        * format of the columns and column size. If the number of columns in the
        * tail does not match the expected columns size, a Left is returned with
        * an error message. If the expected columns size is met, then the
        * commonValueValidated method is called to generate a retValue.
        */
      val fileName = file.name
      if (!file.isEmpty) {

        val fileLineNumber = file.lineCount - 2
        val fileLineCount  = file.lineCount.toInt
        val tailContent =
          file.lineIterator.slice(fileLineCount - 1, fileLineCount).next()

        val tailItems = tailContent.split(delimited)
        if (tailItems.length == colSize) {
          val tailItemsZip = items.zip(tailItems)
          retValue = commonValueValidated(
            fileName,
            tailItemsZip,
            "tail",
            Some(fileLineNumber)
          )
        } else {
          retValue = Left(
            error(
              s"$fileName should right tail format, the tail should have $colSize columns"
            )
          )
        }

      } else {
        retValue = Left(error(s"$fileName should not empty"))
      }
      retValue
    })
  }

  /** fileHeaderValueValidated to validate the input file header has the right
    * value
    * @return
    */
  def fileHeaderValueValidated(
      colSize: Int,
      delimited: String,
      items: List[FileValidationItem]
  ): ValidatePredicate[Errors, File] = {
    ValidatePredicate.liftError(file => {

      var retValue: Either[Errors, Boolean] = Right(true)

      /*
        This code checks the header of a file that is given as an input parameter.
        It uses the delimiter and colSize to check the header size.
        If the size is not the same as colSize, it returns an error otherwise it checks
        the commonValueValidated function to validate the header and returns the result.
       */
      val fileName = file.name
      if (!file.isEmpty) {
        val header      = file.lineIterator.next()
        val headerItems = header.split(delimited)
        if (headerItems.length == colSize) {
          val headerItemsZip = items.zip(headerItems)
          retValue =
            commonValueValidated(fileName, headerItemsZip, "header", None)
        } else {
          retValue = Left(
            error(
              s"$fileName should right header format, the header should have $colSize columns"
            )
          )
        }

      } else {
        retValue = Left(error(s"$fileName should not empty"))
      }
      retValue
    })
  }

  /** fileHasRightHeader function is the Semigroup, it can be combine with the
    * other function
    * @return
    */
  def fileHasRightHeader: ValidatePredicate[Errors, File] = {
    ValidatePredicate.liftError(file => fileHeaderCheck(file))
  }

  def fileHasRightTail: ValidatePredicate[Errors, File] = {
    ValidatePredicate.liftError(file => fileTailCheck(file))
  }
}
