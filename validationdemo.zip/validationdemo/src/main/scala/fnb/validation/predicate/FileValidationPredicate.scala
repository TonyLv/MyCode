package fnb.validation.predicate

import better.files.File
import fnb.validation.common.CommonType._

import java.time.format.DateTimeFormatter
import scala.util.matching.Regex
import scala.util.{Failure, Success, Try}

/** FileValidationPredicate is the class including the different predicates for
  * file validation
  */
class FileValidationPredicate {}

object FileValidationPredicate {

  val fileHeaderDateFormat     = DateTimeFormatter.ofPattern("yyyyMMdd")
  val headerPattern: Regex     = """H,\w+,\d{8}""".r
  val tailPattern: Regex       = """T,\d+""".r
  val numberPattern: Regex     = """\d{8}""".r
  val numberTailPattern: Regex = """\d+""".r

  // Predicate one: File should not be empty
  def fileNotEmpty: ValidatePredicate[Errors, File] =
    ValidatePredicate.lift(
      error(s"File should not be empty!"),
      file => !file.isEmpty
    )

  /** fileHeaderCheck function check the file have right formatted header or not
    * @param file
    * @return
    *   Either[Errors, Boolean]: if the file is not the right header, it's
    *   return Errors
    */
  private def fileHeaderCheck(file: File): Either[Errors, Boolean] = {
    val fileName = file.name
    if (!file.isEmpty) {
      val header = file.lineIterator.next()
      // checking the header's format ---"""H,\w+,\d{8}"""
      headerPattern.findFirstMatchIn(header) match {
        case Some(_) => {
          var headerDateCheckResult: Either[Errors, Boolean] = Right(true)
          header.split(",").foreach { item =>
            // checking the date for the header --- """\d{8}"""
            numberPattern.findFirstMatchIn(item) match {
              case Some(headerItem) => {
                // Using the Try to capture the error when the date format is wrong
                Try(
                  fileHeaderDateFormat.parse(headerItem.toString())
                ) match {
                  case Success(v) => headerDateCheckResult = Right(true)
                  case Failure(e) =>
                    headerDateCheckResult = Left(
                      error(
                        s"$fileName header should have a right date format[yyyyMMdd]!"
                      )
                    )
                }
                headerDateCheckResult
              }
              case None =>
                headerDateCheckResult = Left(
                  error(
                    s"$fileName header should have a right date format[yyyyMMdd]!"
                  )
                )
            }
          }
          headerDateCheckResult
        }
        case None => Left(error(s"$fileName had bad header!"))
      }
    } else {
      Left(error(s"$fileName is empty"))
    }
  }

  /** fileHeaderCheck function check the file have right formatted tail or not
    * @param file
    * @return
    */
  private def fileTailCheck(file: File): Either[Errors, Boolean] = {
    val fileName       = file.name
    val fileLineNumber = file.lineCount - 2
    if (!file.isEmpty) {
      val fileLineCount = file.lineCount.toInt
      val tailContent =
        file.lineIterator.slice(fileLineCount - 1, fileLineCount).next()

      tailPattern.findFirstMatchIn(tailContent) match {
        case Some(_) => {
          var tailCheckResult: Either[Errors, Boolean] = Right(true)
          var tailContentItem = tailContent.split(",").last
          // println(s"--tailContentItems----$tailContentItem")
          if (fileLineNumber != tailContentItem.toLong) {
            tailCheckResult = Left(
              error(s"$fileName should have the right number of the record")
            )
          }
          tailCheckResult
        }
        case None => Left(error(s"$fileName should have the right tail-2"))
      }
    } else {
      Left(error(s"$fileName should have the right tail-3"))
    }
  }

  /** fileHasRightHeader function is the Semigroup, it can be combine with the
    * other function
    * @return
    */
  def fileHasRightHeader: ValidatePredicate[Errors, File] = {
    ValidatePredicate.liftError(file => fileHeaderCheck(file))
  }

  def fileHasRightTail: ValidatePredicate[Errors, File] = {
    ValidatePredicate.liftError(file => fileTailCheck(file))
  }
}
