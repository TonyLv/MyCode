package fnb.validation.conf

import cats.data.Validated.{Invalid, Valid}
import fnb.validation.SparkUnitTestContext
import fnb.validation.check.DataColumnNumberCheck

class DataConfigSetSuit extends SparkUnitTestContext {
  test("data validation config parser testing") {

    assert(
      DataValidationConfig
        .parseFile(
          "data/conf/demodatavalidation.yaml"
        )
        .isRight
    )
  }

  test("run the data validation checking") {

    val df = ss.read
      .option("header", "false")
      .option("inferSchema", "true")
      .csv("data/datavalidation/supermarket_sales_data.txt")

    DataValidationConfig
      .parseFile(
        "data/conf/demodatavalidation.yaml"
      ) match {
      case Right(checkRule) => {
        checkRule.runDataValidationCheckRule().ruleRun(df) match {
          case Valid(a)   => println(a)
          case Invalid(e) => e.map(df => df.show())
        }
      }
    }
  }

  test("run the data validation checking -- DataColumnNumberCheck") {
    val df = ss
      .createDataFrame(
        Seq(
          ("ming", 20, 15552211521L),
          ("hong", 19, 13287994007L),
          ("zhi", 21, 15552211523L)
        )
      )
      .toDF("col1", "col2", "col3")

    val checkColumnNumberCheck = new DataColumnNumberCheck("col1,col2,col3")
    assert(checkColumnNumberCheck.dataCheck(df).isRight)
  }
}
