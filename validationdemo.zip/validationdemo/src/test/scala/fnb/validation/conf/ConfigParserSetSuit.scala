package fnb.validation.conf

import fnb.validation.conf.ConfigParser.parseFile
import org.scalatest.funsuite.AnyFunSuite

class ConfigParserSetSuit extends AnyFunSuite {

  test("Config file parser testing") {

    var error = false

    parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/filevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => println(s"Config: $config")
    }
  }

}
