package fnb.validation.conf

import better.files.StringInterpolations
import cats.data.Validated.{Invalid, Valid}
import org.scalatest.funsuite.AnyFunSuite

class FileValidationConfigParamSetSuit extends AnyFunSuite {
  test("file validation config parser with param testing") {
    var error = false
    FileValidationParamConfig.parseFile(
      "data/conf/positionfilevalidation_new.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
      }
    }
  }

  test("convert file validation config to file validation rule") {
    val file = file"data/testDataFileWithContent.txt"

    var error = false

    FileValidationParamConfig.parseFile(
      "data/conf/positionfilevalidation_new.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
        config.createFileValidationParamCheckRules().ruleRun(file) match {
          case Valid(a)   => println(a)
          case Invalid(e) => println(s"File error: ${e}")
        }
      }
    }
  }
}
