package fnb.validation.conf

import better.files._
import better.files.StringInterpolations
import cats.data.Validated._
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration
import com.amazonaws.regions.Regions
import com.amazonaws.services.s3.AmazonS3ClientBuilder
import org.scalatest.funsuite.AnyFunSuite

import java.net.URI
import scala.util.{Failure, Success, Try}

class ValidationConfigSetSuit extends AnyFunSuite {

  test("Config file parser testing") {

    var error = false

    ValidationConfig.parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/filevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => println(s"Config: $config")
    }
  }

  test("file validation config parser testing") {

    var error = false

    FileValidationConfig.parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/accountfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => println(s"Config: $config")
    }
  }

  test("convert file validation config to file validation rule") {

    val file = file"data/testDataFileWithContent.txt"

    var error = false

    FileValidationConfig.parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/accountfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
        config.createFileValidationCheckRule().ruleRun(file) match {
          case Valid(a)   => println(a)
          case Invalid(e) => println(s"File error: ${e}")
        }
      }
    }
  }

  test("S3 java 1.x: convert file validation config to file validation rule") {

    val endpointConfiguration = new EndpointConfiguration(
      "http://localhost:4566",
      Regions.US_EAST_1.getName()
    );

    val s3 = AmazonS3ClientBuilder
      .standard()
      .withEndpointConfiguration(endpointConfiguration)
      .withPathStyleAccessEnabled(true)
      .build();

    val fileS3 = File.newTemporaryFile();

    Try({
      val o    = s3.getObject("sample-bucket", "testDataFileWithContent.txt")
      val s3is = o.getObjectContent
      // fileS3.appendBytes(s3is.readAllBytes().iterator) // java 11
      val count: Int = s3is.available
      println(s"---count---->${count}")
      val b: Array[Byte] = new Array[Byte](count)
      s3is.read(b)
      fileS3.appendBytes(b.iterator)
      println(s"----fileS3.lineCount----->${fileS3.lineCount}")
      s3is.close()

    }) match {
      case Success(value)     => println(s"--Success--->${value}")
      case Failure(exception) => println(exception)
    }

    val fileLocal = file"data/testDataFileWithContent.txt"

    var error = false

    FileValidationConfig.parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/accountfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
        config.createFileValidationCheckRule().ruleRun(fileS3) match {
          case Valid(a)   => println(a)
          case Invalid(e) => println(s"File error: ${e}")
        }
      }
    }
  }

  test("S3 java 2.x: convert file validation config to file validation rule") {

    import software.amazon.awssdk.regions.Region
    import software.amazon.awssdk.services.s3.S3Client
    import software.amazon.awssdk.services.s3.model.GetObjectRequest

    val region = Region.US_EAST_2
    val s3 = S3Client.builder
      .endpointOverride(URI.create("http://localhost:4566")) // for localstack
      .region(region)
      .build

    val getObjectRequest = GetObjectRequest
      .builder()
      .bucket("sample-bucket")
      .key("testDataFileWithContent.txt")
      .build();

    // val fileS3Obj = s3.getObject(getObjectRequest)
    val fileS3Byte = s3.getObjectAsBytes(getObjectRequest).asByteArrayUnsafe()

    val fileS3 = File.newTemporaryFile();

    fileS3.appendBytes(fileS3Byte.iterator)

    println(s"----fileS3.lineCount----->${fileS3.lineCount}")

    var error = false

    FileValidationConfig.parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/accountfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
        config.createFileValidationCheckRule().ruleRun(fileS3) match {
          case Valid(a)   => println(a)
          case Invalid(e) => println(s"File error: ${e}")
        }
      }
    }
  }

}
