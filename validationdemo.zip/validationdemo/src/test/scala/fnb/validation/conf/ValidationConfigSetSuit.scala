package fnb.validation.conf

import better.files.StringInterpolations
import cats.data.Validated._
import org.scalatest.funsuite.AnyFunSuite

class ValidationConfigSetSuit extends AnyFunSuite {

  test("file validation config parser testing") {

    var error = false

    FileValidationConfig.parseFile(
      "data/conf/positionfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => println(s"Config: $config")
    }
  }

  test("convert file validation config to file validation rule") {

    val file = file"data/testDataFileWithContent.txt"

    var error = false

    FileValidationConfig.parseFile(
      "data/conf/positionfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
        config.createFileValidationCheckRule().ruleRun(file) match {
          case Valid(a)   => println(a)
          case Invalid(e) => println(s"File error: ${e}")
        }
      }
    }
  }

  /*test("S3 java 1.x: convert file validation config to file validation rule") {

    val endpointConfiguration = new EndpointConfiguration(
      "http://localhost:4566",
      Regions.US_EAST_1.getName()
    );

    val s3 = AmazonS3ClientBuilder
      .standard()
      .withEndpointConfiguration(endpointConfiguration)
      .withPathStyleAccessEnabled(true)
      .build();

    val fileS3 = File.newTemporaryFile();

    Try({
      val o    = s3.getObject("sample-bucket", "testDataFileWithContent.txt")
      val s3is = o.getObjectContent

      /*
      val read_buf = new Array[Byte](1024)
      var read_len = 0L

      do {
        read_len = s3is.read(read_buf)
        fileS3.appendBytes(read_buf.iterator)
      } while (read_len > 0)*/

      import java.io.BufferedReader
      import java.io.InputStreamReader

      val reader = new BufferedReader(new InputStreamReader(s3is))

      var line: String = null

      do {
        line = reader.readLine()
        fileS3.appendLine(line)
      } while (line != null)

      // fileS3.appendBytes(s3is.readAllBytes().iterator) // java 11
      /*
      val count: Int = s3is.available
      println(s"---count---->${count}")
      val b: Array[Byte] = new Array[Byte](count)
      s3is.read(b)
      fileS3.appendBytes(b.iterator)*/
      println(s"----fileS3.lineCount----->${fileS3.lineCount}")
      s3is.close()

    }) match {
      case Success(value)     => println(s"--Success--->${value}")
      case Failure(exception) => println(exception)
    }

    val fileLocal = file"data/testDataFileWithContent.txt"

    var error = false

    FileValidationConfig.parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/positionfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
        config.createFileValidationCheckRule().ruleRun(fileS3) match {
          case Valid(a)   => println(a)
          case Invalid(e) => println(s"File error: ${e}")
        }
      }
    }
  }*/

  /*test("S3 java 2.x: convert file validation config to file validation rule") {

    import software.amazon.awssdk.regions.Region
    import software.amazon.awssdk.services.s3.S3Client
    import software.amazon.awssdk.services.s3.model.GetObjectRequest

    val region = Region.US_EAST_2
    val s3 = S3Client.builder
      .endpointOverride(URI.create("http://localhost:4566")) // for localstack
      .region(region)
      .build

    val getObjectRequest = GetObjectRequest
      .builder()
      .bucket("sample-bucket")
      .key("testDataFileWithContent.txt")
      .build();

    // val fileS3Obj = s3.getObject(getObjectRequest)
    val fileS3Byte = s3.getObjectAsBytes(getObjectRequest).asByteArrayUnsafe()

    val fileS3 = File.newTemporaryFile();

    fileS3.appendBytes(fileS3Byte.iterator)

    println(s"----fileS3.lineCount----->${fileS3.lineCount}")

    var error = false

    FileValidationConfig.parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/positionfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
        config.createFileValidationCheckRule().ruleRun(fileS3) match {
          case Valid(a)   => println(a)
          case Invalid(e) => println(s"File error: ${e}")
        }
      }
    }
  }*/

  /*test("InputStream: convert file validation config to file validation rule") {

    import scala.io.Source
    import scala.util.{Try, Success, Failure}

    val endpointConfiguration = new EndpointConfiguration(
      "http://localhost:4566",
      Regions.US_EAST_1.getName()
    );

    val s3 = AmazonS3ClientBuilder
      .standard()
      .withEndpointConfiguration(endpointConfiguration)
      .withPathStyleAccessEnabled(true)
      .build();

    val fileS3 = File.newTemporaryFile();

    Try({
      val o    = s3.getObject("sample-bucket", "testDataFileWithContent.txt")
      val s3is = o.getObjectContent

      var fileBufferio = Source.fromInputStream(s3is)

      fileS3.appendLine(fileBufferio.mkString)

      println(s"----fileS3.lineCount----->${fileS3.lineCount}")

      fileBufferio.close()
      s3is.close()

    }) match {
      case Success(value)     => println(s"--Success--->${value}")
      case Failure(exception) => println(exception)
    }

    var error = false

    FileValidationConfig.parseFile(
      "/Users/mac/Desktop/Projects/scala/easyrule/validationdemo/data/conf/positionfilevalidation.yaml"
    ) match {
      case Left(pe) =>
        println(s"-----error---${pe}")
        error = true
      case Right(config) => {
        println(s"Config: $config")
        config.createFileValidationCheckRule().ruleRun(fileS3) match {
          case Valid(a)   => println(a)
          case Invalid(e) => println(s"File error: ${e}")
        }
      }
    }

  }*/

}
