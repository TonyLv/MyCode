package fnb.validation

import better.files._
import cats.data.Validated.{Invalid, Valid}
import org.scalatest.matchers.must.Matchers.be
import org.scalatest.matchers.should.Matchers.{a, convertToAnyShouldWrapper}

class ValidationToolsSetSuit extends SparkUnitTestContext {
  test("Testing the file validation call") {
    val confFile = file"data/conf/positionfilevalidation_new.yaml"
    val dataFile = file"data/testDataFileWithContent.txt"

    val retValue =
      ValidationTools.doFileValidation(confFile.newFileInputStream, dataFile)

    retValue match {
      case Valid(a) => {
        println(a)
      }
      case Invalid(e) => {
        println(e)
      }
    }

    retValue should be a 'Invalid
  }

  test("Testing the data validation call") {

    val confFile = file"data/conf/demodatavalidation.yaml"

    val df = ss.read
      .option("header", "false")
      .option("inferSchema", "true")
      .csv("data/datavalidation/supermarket_sales_data.txt")

    val retValue =
      ValidationTools.doDataValidationForSpark(confFile.newFileInputStream, df)

    retValue match {
      case Valid(a) => {
        println(a)
      }
      case Invalid(e) => {
        println(e.map(eDf => eDf.show()))
      }
    }

    retValue should be a 'Invalid

  }

}
