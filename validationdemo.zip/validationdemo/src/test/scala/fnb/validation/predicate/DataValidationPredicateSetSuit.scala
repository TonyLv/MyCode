package fnb.validation.predicate

import cats.data.Validated.{Invalid, Valid}
import fnb.validation.SparkUnitTestContext
import org.apache.spark.sql.functions.{col, lit}

class DataValidationPredicateSetSuit extends SparkUnitTestContext {

  /*test("Spark function test -----> test for StructField to create schema") {

    val columns = Seq("language", "users_count")
    val data = Seq(("Java", "20000"), ("Python", "100000"), ("Scala", "1000"))
    val rdd  = sc.parallelize(data)

    // From RDD (USING toDF())
    /*    val dfFromRDD1 = rdd.toDF("language", "users")
    dfFromRDD1.printSchema()*/
    // From RDD (USING createDataFrame)
    val dfFromRDD2 = ss.createDataFrame(rdd).toDF(columns: _*)
    dfFromRDD2.printSchema()
    // From RDD (USING createDataFrame and Adding schema using StructType)
    // convert RDD[T] to RDD[Row]
    val schema = StructType(
      Array(
        StructField("user", StringType, true),
        StructField("language", StringType, true)
      )
    )

    val rowRDD     = rdd.map(attributes => Row(attributes._1, attributes._2))
    val dfFromRDD3 = ss.createDataFrame(rowRDD, schema)

    dfFromRDD3.printSchema()

    // From Data (USING toDF())
    // val dfFromData1 = data.toDF()

    // From Data (USING createDataFrame)
    var dfFromData2 = ss.createDataFrame(data).toDF(columns: _*)

    // From Data (USING createDataFrame and Adding schema using StructType)
    import scala.collection.JavaConversions._
    val rowData = data
      .map(attributes => Row(attributes._1, attributes._2))
    var dfFromData3 = ss.createDataFrame(rowData, schema)

  }*/

  /*test("Spark functional test --- set the schema to txt file") {

    val schemaString =
      s"Invoice ID,Branch,City,Customer type,Gender,Product line,Unit_price,Quantity," +
        s"Tax_5%,Total,Date,Time,Payment,cogs,gross_margin_percentage,gross_income,Rating"
    val fields = schemaString
      .split(",")
      .map(fieldName => StructField(fieldName, StringType, nullable = true))
    val schema = StructType(fields)

    val fileRdd =
      sc.textFile("data/datavalidation/supermarket_sales_data.txt")
        .map(_.split(","))
        .map { x => org.apache.spark.sql.Row(x: _*) }
    val sqlDf = ss.createDataFrame(fileRdd, schema)
    sqlDf.show()

  }*/

  test("Spark functional test --- check the column exists") {
    val df = ss.read
      .option("header", "false")
      .option("inferSchema", "true")
      .csv("data/datavalidation/supermarket_sales_data.txt")

    val schemaString =
      s"Invoice ID,Branch,City,Customer type,Gender,Product line,Unit_price,Quantity," +
        s"Tax_5%,Total,Date,Time,Payment,cogs,gross_margin_percentage,gross_income,Rating"

    val schemaArray = schemaString.split(",")
    val columnArray = df.columns

    val colMapSchema = columnArray.zip(schemaArray).toMap

    val newDf = df.select(colMapSchema.map { case (oldCol, newCol) =>
      col(oldCol).as(newCol)
    } toSeq: _*)

    // val newDf = df.selectExpr(schemaString.split(",").flatten)

    df.show(5)
    newDf.show(5)

  }

  test("Spark functional test --- add the new column into dataframe") {
    val df = ss
      .createDataFrame(
        Seq(
          ("ming", 20, 15552211521L),
          ("hong", 19, 13287994007L),
          ("zhi", 21, 15552211523L)
        )
      )
      .toDF("col1", "col2", "col3")

    df.withColumn("type", lit("mr")).show

  }

  test("data validate predicate functional test --- validateNumberOfColumns") {

    val df = ss
      .createDataFrame(
        Seq(
          ("ming", 20, 15552211521L),
          ("hong", 19, 13287994007L),
          ("zhi", 21, 15552211523L)
        )
      )
      .toDF("col1", "col2", "col3")

    val realColumns = "col1,col2"

    assert(
      !DataValidationPredicate
        .validateNumberOfColumns(realColumns)
        .apply(df)
        .isValid
    )

  }

  test("data validate predicate functional test --- setUserDefinedColumn") {

    val df = ss
      .createDataFrame(
        Seq(
          ("ming", 20, 15552211521L),
          ("hong", 19, 13287994007L),
          ("zhi", 21, 15552211523L)
        )
      )
      .toDF("col1", "col2", "col3")

    val realColumns = "name,age,size"

    DataValidationPredicate
      .setUserDefinedColumn(df, realColumns) match {
      case Right(df) => df.printSchema()
      case Left(e)   => println(s"$e")
    }

  }

  test("data validate predicate functional test --- valiatedColLength") {

    val df = ss
      .createDataFrame(
        Seq(
          ("ming", 20, 15552211521L),
          ("hong", 19, 13287994007L),
          ("zhi", 21, 15552211523L)
        )
      )
      .toDF("col1", "col2", "col3")

    DataValidationPredicate
      .valiatedColLength("col1", 3)
      .apply(df) match {
      case Valid(a)   => a
      case Invalid(e) => e.last.show()
    }

  }

  test("data validate predicate functional test --- validatedColValue") {
    val df = ss
      .createDataFrame(
        Seq(
          ("ming", "N", 15552211521L),
          ("hong", "Y", 13287994007L),
          ("zhi", "I", 15552211523L)
        )
      )
      .toDF("col1", "col2", "col3")

    val valueList: Seq[String] = List("N", "Y")

    DataValidationPredicate
      .validatedColValue("col2", valueList)
      .apply(df) match {
      case Valid(a)   => a
      case Invalid(e) => e.last.show()
    }

  }

  test("data validate predicate functional test --- validateColDecimalScale") {
    val df = ss
      .createDataFrame(
        Seq(
          ("ming", "N", 15552211521L, "233.00998"),
          ("hong", "Y", 13287994007L, "33.998"),
          ("zhi", "I", 15552211523L, "233.233455")
        )
      )
      .toDF("col1", "col2", "col3", "col4")

    DataValidationPredicate
      .validateColDecimalScale("col4", 5)
      .apply(df) match {
      case Valid(a)   => a
      case Invalid(e) => e.last.show()
    }

  }

  test("data validate predicate functional test --- validateColDateFormat") {

    val df = ss
      .createDataFrame(
        Seq(
          ("ming", 20, 15552211521L, "2022-03-13"),
          ("hong", 19, 13287994007L, "20220313"),
          ("zhi", 21, 15552211523L, "2022-03-13")
        )
      )
      .toDF("col1", "col2", "col3", "col4")

    DataValidationPredicate
      .validateColDateFormat(
        "col4",
        "YYYY-MM-DD"
      ) // YYYY-MM-DD
      .apply(df) match {
      case Valid(a)   => a
      case Invalid(e) => e.last.show()
    }

  }
}
