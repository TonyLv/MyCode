package fnb.validation.predicate

import org.scalatest.funsuite.AnyFunSuite
import better.files._
import fnb.validation.check.FileValidationCheck
import fnb.validation.predicate.FileValidationPredicate._

import java.io.{File => JFile}

class FileValidationPredicateSetSuit extends AnyFunSuite {

  test("Betterfile---File should not be empty! ") {

    val fileEmpty = file"data/testDataFile.txt"

    assert(fileEmpty.isEmpty)
  }

  test("Batterfile---File should have header ") {

    val fileHeader = file"data/testDataFileWithContent.txt"

    var fileFirstRow = fileHeader.lineIterator.next

    println(s"fileFirstRow--->$fileFirstRow")

    assert(!fileFirstRow.isEmpty)
  }

  test("File should not be empty!") {

    var emptyFile = file"data/testDataFile.txt"

    var fileValidationCheck = FileValidationCheck(emptyFile)
    println(fileValidationCheck.commonFileEmptyCheck.run(emptyFile))
  }

  test(
    "File should not be empty! and File should have right formatted header "
  ) {

    val file = file"data/testDataFileWithContent.txt"

    var fileValidationCheck_ = FileValidationCheck(file)
    println(fileValidationCheck_.commonFileFormatCheck.run(file))
  }

}
