package fnb.validation.predicate

import org.scalatest.funsuite.AnyFunSuite
import better.files._
import fnb.validation.check._
import fnb.validation.predicate.FileValidationPredicate._

import java.io.{File => JFile}

class FileValidationPredicateSetSuit extends AnyFunSuite {

  test("Betterfile---File should not be empty! ") {

    val fileEmpty = file"data/testDataFile.txt"

    assert(fileEmpty.isEmpty)
  }

  test("Batterfile---File should have header ") {

    val fileHeader = file"data/testDataFileWithContent.txt"

    var fileFirstRow = fileHeader.lineIterator.next

    println(s"fileFirstRow--->$fileFirstRow")

    assert(!fileFirstRow.isEmpty)
  }

  test("File should not be empty!") {

    var emptyFile = file"data/testDataFile.txt"

    var fileValidationCheck = FileEmptyValidationCheck()
    println(fileValidationCheck.fileCheck.run(emptyFile))
  }

  test(
    "File should not be empty! and File should have right formatted header "
  ) {

    val file = file"data/testDataFileWithContent.txt"

    var fileValidationCheck_ = FileHeaderValidationCheck()
    println(fileValidationCheck_.fileCheck.run(file))
  }

  test(
    "File should not be empty! and File should have right formatted tailor "
  ) {

    val file = file"data/testDataFileWithContent.txt"

    var fileValidationCheck_ = FileTailerValidationCheck()
    println(fileValidationCheck_.fileCheck.run(file))
  }

  test(
    "File should not be empty and File should have right formatted header " +
      "and File should have right formatted tailor "
  ) {

    val file = file"data/testDataFileWithContent.txt"

    var fileValidationCheck_Tailer = FileTailerValidationCheck()
    var fileValidationCheck_Header = FileHeaderValidationCheck()

    println(
      (fileValidationCheck_Header.fileCheck andThen fileValidationCheck_Tailer.fileCheck)
        .run(file)
    )
  }

}
