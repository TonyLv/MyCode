package fnb.validation.predicate

import better.files._
import cats.data.NonEmptyList
import cats.implicits.catsStdInstancesForEither
import fnb.validation.check._
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.matchers.must.Matchers.be
import org.scalatest.matchers.should.Matchers.convertToAnyShouldWrapper

class FileValidationPredicateSetSuit extends AnyFunSuite {

  test("Betterfile---File should not be empty! ") {

    val fileEmpty = file"data/testDataFile.txt"

    assert(fileEmpty.isEmpty)
  }

  test("Batterfile---File should have header ") {

    val fileHeader = file"data/testDataFileWithContent.txt"

    val fileFirstRow = fileHeader.lineIterator.next

    println(s"fileFirstRow--->$fileFirstRow")

    assert(fileFirstRow.nonEmpty)
  }

  test("File should not be empty!") {

    val emptyFile = file"data/testDataFile.txt"

    val fileValidationCheck = FileEmptyValidationCheck()

    fileValidationCheck.fileCheck.run(emptyFile) should be(
      Left(NonEmptyList("File should not be empty!", List()))
    )
  }

  test(
    "File should not be empty! and File should have right formatted header "
  ) {

    val file = file"data/testDataFileWithContent.txt"

    val fileValidationCheck_ = FileHeaderValidationCheck()
    fileValidationCheck_.fileCheck.run(file) should be(
      Left(
        NonEmptyList(
          "testDataFileWithContent.txt header should have a right date format[yyyyMMdd]!",
          List()
        )
      )
    )
  }

  test(
    "File should not be empty! and File should have right formatted tailor "
  ) {

    val file = file"data/testDataFileWithContent.txt"

    val fileValidationCheck_ = FileTailerValidationCheck()
    fileValidationCheck_.fileCheck.run(file) should be(
      Left(
        NonEmptyList(
          "testDataFileWithContent.txt should have the right number of the record",
          List()
        )
      )
    )
  }

  test(
    "File should not be empty and File should have right formatted header " +
      "and File should have right formatted tailor "
  ) {

    val file = file"data/testDataFileWithContent.txt"

    val fileValidationCheck_Tailer = FileTailerValidationCheck()
    val fileValidationCheck_Header = FileHeaderValidationCheck()

    (fileValidationCheck_Header.fileCheck andThen fileValidationCheck_Tailer.fileCheck)
      .run(file) should be(
      Left(
        NonEmptyList(
          "testDataFileWithContent.txt header should have a right date format[yyyyMMdd]!",
          List()
        )
      )
    )
  }

}
