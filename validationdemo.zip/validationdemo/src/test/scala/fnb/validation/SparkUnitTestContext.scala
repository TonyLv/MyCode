package fnb.validation

import org.apache.spark.sql.{SQLContext, SQLImplicits, SparkSession}
import org.apache.spark.{SparkConf, SparkContext}
import org.scalatest.funsuite.AnyFunSuite
import org.scalatest.{BeforeAndAfterAll, BeforeAndAfterEach}

trait SparkUnitTestContext
    extends AnyFunSuite
    with BeforeAndAfterEach
    with BeforeAndAfterAll {
  @transient var ss: SparkSession = _
  @transient var sc: SparkContext = _

  private object testImplicits extends SQLImplicits {
    override protected def _sqlContext: SQLContext = ss.sqlContext
  }

  override def beforeAll(): Unit = {
    val sparkConfig = new SparkConf()
    sparkConfig.set("spark.broadcast.compress", "false")
    sparkConfig.set("spark.shuffle.compress", "false")
    sparkConfig.set("spark.shuffle.spill.compress", "false")
    sparkConfig.set("spark.master", "local")
    ss = SparkSession.builder().config(sparkConfig).getOrCreate()
  }

  override def afterAll(): Unit = {
    ss.stop()
  }
}
